package stepdef;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.json.simple.parser.ParseException;
import org.junit.Assert;
import org.openqa.selenium.support.ui.WebDriverWait;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.AddPersonYouLiveWith;
import gov.dhsc.qat.nhstt.pageobjects.BookFreeTestScreenObjects_old;
import gov.dhsc.qat.nhstt.pageobjects.CountryOfResidenceScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.EmployerDetailsScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.EssentialWorkerScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.FullHomeAddressScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects_old;
import gov.dhsc.qat.nhstt.pageobjects.NInumberScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.OccupationScreenObjects;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BookTheTestStepDef extends InitiateWebBrowser 
{
	public BookTheTestStepDef() throws IOException
	{
		super();
	}

	HomeScreenObjects home;
	MainScreenObjects_old main;
	BookFreeTestScreenObjects_old booktest;
	CountryOfResidenceScreenObjects countryofresidence;
	OccupationScreenObjects occupationscreen;
	EmployerDetailsScreenObjects employerdetails;
	AddPersonYouLiveWith addpersonyoulivewith;
	NInumberScreenObjects ninumber;
	FullHomeAddressScreenObjects fullhouseaddress;
	EssentialWorkerScreenObjects essentialworker;
	MainScreenObjects main1;
	
	
	static Set<String> contextNames;
	static WebDriverWait wait;

	@SuppressWarnings("rawtypes")
	@Given("User is on the home page of the mobile app")
	public void user_is_on_the_home_page_of_the_mobile_app() throws IOException
	{	  
		InitiateWebBrowser.initiateWebBrowser();
	}

	@When("User click in the main screen buttonone")
	public void user_click_in_the_main_screen_buttonone() throws IOException 
	{
		home= new HomeScreenObjects(driver);
		home.clickOnMainScreenBtn();
		
	}

	@SuppressWarnings("static-access")
	@When("User book for a free test")
	public void User_book_for_a_free_test() throws IOException, InterruptedException
	{
		main = new MainScreenObjects_old(driver);
		main.clickOnBookFreeTest();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		main.swipeToBottom();
		booktest = new BookFreeTestScreenObjects_old(driver);
		booktest.clickOnBookFreeTestNow();
	}
	@When("User has to select its part of trial or government project")
	public void user_has_to_select_its_part_of_trial_or_government_project() throws InterruptedException {
	   booktest.partOfTrialOrGovernmentProject("Yes");
	}
	@When("User has to select the person is part of a trial or gov project")
	public void user_has_to_select_the_person_is_part_of_a_trial_or_gov_project() throws InterruptedException {
		booktest.partOfTrialOrGovernmentProject("No");
	}
	
	
	@When("User has to provide the name details")
	public void user_has_to_provide_the_name_details() throws InterruptedException, IOException 
	{
		booktest = new BookFreeTestScreenObjects_old(driver);
		String firstname=prop.getProperty("firstName");
		String lastName=prop.getProperty("lastName");		
		booktest.firstNamelastNameScreen(firstname,lastName);	
		System.out.println(firstname+lastName);
	 
	}

	@When("User has to provide the mobile number")
	public void user_has_to_provide_the_mobile_number() throws InterruptedException {
		booktest.selectMobile("Yes");
		booktest.enterMobileNumber(prop.getProperty("mobileNumber"));
		Thread.sleep(10);
		System.out.println("mobileNumber :"+ prop.getProperty("mobileNumber"));
		}	
		
	@When("User has to provide an email address")
	public void user_has_to_provide_an_email_address() throws InterruptedException {
		booktest.selectEmailoption(prop.getProperty("emailAvailable"));
		booktest.enterEmailAddress(prop.getProperty("emailAddress"));
		System.out.println("emailAddress "+prop.getProperty("emailAddress"));
	}

	@When("User has to provide the rough symptoms start date")
	public void user_has_to_provide_the_rough_symptoms_start_date() throws InterruptedException, IOException {
		LocalDate date = LocalDate.now().minusDays(2);
		String date1= Integer.toString(date.getDayOfMonth());
		String month = Integer.toString(date.getMonthValue());
		String year= Integer.toString(date.getYear());
		main1 = new MainScreenObjects(driver);
	//	main1.switchContext();
		String startdate = date1;
		String startmonth = month;
		String startyear = year;
		booktest.enterSymptomsStartDate(startdate,startmonth,startyear);
		Thread.sleep(10);
	}
	@When("User has to provide the postcode")
	public void user_has_to_provide_the_postcode() throws InterruptedException 
	{
		booktest.enterPostcode(prop.getProperty("postcode"));
		System.out.println("postcode "+prop.getProperty("postcode"));
	}
	
	@When("User select yes to having coronavirus symptom")
	public void User_select_yes_to_having_coronavirus_symptom  () throws InterruptedException 
	{
		booktest.ClickHavingCoronaSymptom();	
	}


	@When("User has to provide vehicle not accessible")
	public void user_has_to_provide_vehicle_not_accessible() throws InterruptedException 
	{
		booktest.vehicleAccess(prop.getProperty("vehicleoptionNo"));
	}
	
	@When("User has to provide vehicle accessible")
	public void user_has_to_provide_vehicle_accessible() throws InterruptedException
	{
		booktest.vehicleAccess(prop.getProperty("vehicleoptionYes"));		
	}

	@SuppressWarnings("static-access")
	@Then("User review the answers")
	public void user_review_the_answers() throws InterruptedException {
		
		main.swipeToBottom();
		booktest.checkSelectedAnswers();
	
	}
	@When("User select At a walk-through test site")
	public void user_select_at_a_walk_through_test_site() throws InterruptedException {
	   booktest.clickOnWalkThroughSite();
	}
	
	@SuppressWarnings("static-access")
	@When("User select At a drive-through test site")
	public void user_select_at_a_drive_through_test_site() throws InterruptedException {
		
		booktest.clickOnDriveThroughSite();
	}

	@When("User reads the advice for visiting a drive")
	public void user_reads_the_advice_for_visiting_a_drive() throws InterruptedException {
	    booktest.readAdviceForVisitingDrive();
	 //   booktest.clickContinue();
		    
	}
	
	@When("User select Hometesting")
	public void user_select_hometesting() throws InterruptedException {
	   booktest.clickOnHomeTesting();
	}

	@When("User reads Order a home test kit: what you need to know")
	public void user_reads_order_a_home_test_kit_what_you_need_to_know() throws InterruptedException {
		booktest.orderHomeTestKitWhattoKnow();
	}

	@When("User enters date of birth of the person needing a test")
	public void user_enters_date_of_birth_of_the_person_needing_a_test() {
		String date= prop.getProperty("dateofbirth");
		String month= prop.getProperty("monthofbirth");
		String year= prop.getProperty("yearofbirth");
		booktest.enterDOB(date,month,year);
		System.out.println(date+month+year);
	}

	@When("User enters a landline phone number")
	public void user_enters_a_landline_phone_number() throws InterruptedException {
		booktest.landlineNotAvailabile();		
	}

	@When("User enters email address")
	public void user_enters_email_address() throws InterruptedException {
		booktest.enterEmailAddress(prop.getProperty("emailAddress"));
		
	}

	@When("User has to provide a Gender detail")
	public void user_has_to_provide_a_gender_detail() {
		booktest.selectGender(prop.getProperty("gender"));
		System.out.println(prop.getProperty("gender"));
	}

	@When("User has to provide a Ethnic group")
	public void user_has_to_provide_a_ethnic_group() {
	   booktest.enterEthnicityGroup(prop.getProperty("EthnicgroupPreferNottosay"));
	   System.out.println(prop.getProperty("EthnicgroupPreferNottosay"));
	}

	@When("User selects currently not in work field")
	public void user_selects_currently_not_in_work_field() {
	    booktest.currentWorkStatus(prop.getProperty("currentWorkStatusNo"));
	}
	
	@When("User selects currently in work field")
	public void user_selects_currently_in_work_field() {
	    booktest.currentWorkStatus(prop.getProperty("currentWorkStatusYesTravelled"));
	    }
	@When("User selects currently working from home")
	public void user_selects_currently_working_from_home() {
		booktest.currentlyWorkingFromHome();	    
	}
	
	@When("User selects area of work")
	public void user_selects_area_of_work() throws InterruptedException {
	    booktest.areaOfWorkRetail();
	}

	@When("User selects occupation of the person")
	public void user_selects_occupation_of_the_person() throws IOException {
		OccupationScreenObjects occupationscreen=new OccupationScreenObjects(driver);
		occupationscreen.selectOccupationListBox();
		occupationscreen.clickOnContinue();
	}

	@When("User selects name of the employer")
	public void user_selects_name_of_the_employer() throws IOException {
		employerdetails= new EmployerDetailsScreenObjects(driver);
		employerdetails.employerDetails();
	}

	@When("User has to provide a country of residence")
	public void user_has_to_provide_a_country_of_residence() {
	    booktest.countryOfResidence(prop.getProperty("CountryScotland"));
	}
	
	
	@When("User selects know your NHS number details")
	public void user_selects_know_your_nhs_number_details() {
	   booktest.nhsnumberAvailability(prop.getProperty("NHSYes"));
	}
	@When("User selects dont know the NHS number details")
	public void user_selects_dont_know_the_NHS_number_details() {
	   booktest.nhsnumberAvailability(prop.getProperty("NHSNo"));
	}

	@When("User enters NHS number")
	public void user_enters_nhs_number() {
	    booktest.enternhsnumber(prop.getProperty("nhsNumber"));
	}

	@When("User verify the answers")
	public void user_verify_the_answers() {
		booktest.verifyAnswers();
	}

	@When("User adds a person detail who live with")
	public void user_adds_a_person_detail_who_live_with() throws IOException {
		AddPersonYouLiveWith addpersonyoulivewith=new AddPersonYouLiveWith(driver);
		addpersonyoulivewith.selectAddPersonYouLiveWith();
	}


	@When("User has to provide postcode to find a site")
	public void user_has_to_provide_postcode_to_find_a_site()
	{
		booktest.enterPostcodeTestsite(prop.getProperty("postcode")); 
		// ha84tr  , SW1H0EU , SW82UP, E12FB, N14BZ
	}

	@When("User has to select the slots based on the availability")
	public void user_has_to_select_the_slots_based_on_the_availability() throws InterruptedException
	{
	     booktest.chooseTestSite(prop.getProperty("testsite"));
	}

	@When("User has to select the time for appointment")
	public void user_has_to_select_the_time_for_appointment() throws InterruptedException 
	{
	    booktest.chooseTimeSlot();
	
	}

	@When("User enters vehicle registration number")
	public void user_enters_vehicle_registration_number()
	{
		booktest.vehicleRegistrationNumber(prop.getProperty("registrationnumber"));
	}
	@When("User enters valid NI number")
	public void user_enters_valid_NI_number() throws IOException
	{
		NInumberScreenObjects ninumber = new NInumberScreenObjects(driver);
		ninumber.niNumberAvailable();
		ninumber.enterNINumber();
	}
    @When("User confirms postcode")
    public void user_confirms_postcode()
    {
    	booktest.enterPostcode(prop.getProperty("postcode"));
    }
    @When("User select full home address from the list")
    public void user_select_full_home_address_from_the_list() throws IOException
    {
    	FullHomeAddressScreenObjects fullhouseaddress = new FullHomeAddressScreenObjects(driver);
    	fullhouseaddress.clickOnFindAddress();
    }
        
	@When("User confirms the appointment")
	public void user_confirms_the_appointment() throws InterruptedException 
	{
		booktest.confirmAppointmentDetails();
	}
	
	@When("User changes the test site")
	public void user_changes_the_test_site()
	{
		booktest.selectChangeTestSite();
	}
	@When("User select change to walkthrough")
	public void user_select_change_to_walkthrough() {
	    booktest.selectChangeToWalkthrough();
	}
	
	@Then("User verify the appointment email confirmation")
	public void user_verify_the_appointment_email_confirmation() throws InterruptedException 
	{
	    booktest.confirmAppointmnetBooked();
	}
	
	@Then("User recieves Confirmation should be received on Home Testing Kit will be sent to the Address")
	public void user_recieves_confirmation_should_be_received_on_Home_Testing_Kit_will_be_sent_to_the_Address()
	{
		
	}
	
	@When("User select NO to essential worker")
	public void user_select_no_to_essential_worker() throws IOException, InterruptedException
	{
		essentialworker= new EssentialWorkerScreenObjects(driver);
		essentialworker.selectEssentialWorker(prop.getProperty("essentialworkeroptionNo"));
		System.out.println("essentialworker :" + prop.getProperty("essentialworkeroptionNo"));
      // booktest.partOfTrialOrGovernmentProject("No");
		//Thread.sleep(4000);

	}

	@When("User has to provide the vehicle access details")
	public void user_has_to_provide_the_vehicle_access_details() throws InterruptedException 
	{ 
       booktest.vehicleAccess(prop.getProperty("vehicleoptionNo"));
       System.out.println("vehicleoptionNo "+prop.getProperty("vehicleoptionNo"));
	}
	
	@When("user clicks on continue to ask few more questions")
	public void user_clicks_on_continue_to_ask_few_more_questions() throws InterruptedException, IOException 
	{ 
	
       booktest.clickOnContinuetoaskMoreQues();
	}
	
	@When("User Confirm the person is eligible for test")
	public void user_confirm_the_person_is_eligible_for_test() throws InterruptedException 
	{

      MainScreenObjects.swipeToBottom();
      booktest.ClickonConfirmandcontinue();
	
	}
	@Then("User gets a screen with message How do you want to get the coronavirus test?")
	public void user_gets_a_screen_with_message_how_do_you_want_to_get_the_coronavirus_test() throws InterruptedException 
	 {
      MainScreenObjects.swipeToBottom1();
     //booktest.clickOnHomeTesting();
	}
	@Then("User select Home Testing and click on Continue")
	public void user_select_home_testing_and_click_on_continue() throws InterruptedException 
	{
	      booktest.clickOnHomeTesting();
	}
	@Then("User review page and clicks on continue")
	public void user_review_page_and_clicks_on_continue() throws InterruptedException 
	{
		MainScreenObjects.swipeToBottom();
		MainScreenObjects.swipeToBottom();
		booktest.clickContinue();
	}
	

	@Then("User Confirm people for testing")
	public void user_confirm_people_for_testing() throws InterruptedException 
	{
		/*String toVerify="Confirm people for testing";
		String actual=booktest.getConfirmHeader();
		System.out.println("actual :"+actual);
		Assert.assertEquals(toVerify, actual);*/
		//booktest.ClickonSaveAndcontinue();
		
	}
	@Then("User click Save and Continue")
	public void user_click_save_and_continue() throws InterruptedException
	 {
		  MainScreenObjects.swipeToBottom();
		  booktest.ClickonSaveAndcontinue();
	}
	
	@Then ("User checks ans and clicks on save and continue")
	public void check_and_confirm()
	{
		booktest.verifyAnswers();
	}
	@Then("User selects NO to add person you live with and clicks on Save and Continue")
	public void user_selects_no_to_add_person_you_live_with_and_clicks_on_save_and_continue() 
	{

	}
	@Then("user clicks on continue")
	public void user_clicks_on_continue() 
	{

	}
	@Then("User enters valid NI number and click on continue")
	public void user_enters_valid_ni_number_and_click_on_continue() 
	{

     booktest.EnterNINumber(prop.getProperty("NINumber"));
     
	}
	
	@Then("User enters Yes to Know NI Number")
	public void User_enters_Yes_to_Know_NI_Number() 
	{
     booktest.doYouKnowNINumber(prop.getProperty("YesNI"));
     
	}
	@Then("User enters No NI Number")
	public void user_enters_no_ni_number()
	 {
	  booktest.doYouKnowNINumber("No");
	}
	
	@Then("User enters valid PostCode and clicks on Find address")
	public void user_enters_valid_post_code_and_clicks_on_continue() 
	{
     booktest.Enterpostcodeforhomeaddress(prop.getProperty("postcode"));
     booktest.clickonFindAddress();
	}
	
	@Then("User selects complete home address from list")
	public void user_selects_complete_home_address_from_list() 
	{
		
     booktest.selectAddress(prop.getProperty("houseno"));
	}
	@Then("User select yes to delivery address same as home address")
	public void User_select_yes_to_delivery_address_same_as_home_address() 
	{
    
      booktest.selectYesToHomeAddressSameasDelivery(prop.getProperty("HomeAddressSameasDelivery"));
	}
	
	@Then("User select no my delivery address is different to my home address")
	public void User_select_no_my_delivery_address_is_different_to_my_home_address()
	{
		booktest.selectYesToHomeAddressSameasDelivery("No");
	}
	
	@Then("User Confirm Email Address") 
	public void confirm_email()
	{
		//booktest.confirmEmail();
	}
	@Then("Confirmation should be received on Home Testing Kit will be sent to the Address")
	public void user_should_be_received_on_home_testing_kit_will_be_sent_to_the_address() 
	{
     
	}
	
	@Given("User is on the Web Portal")
	public void user_is_on_the_web_portal() throws IOException, InterruptedException, ParseException
	 {
		InitiateWebBrowser.initiateWebBrowser();
		driver.get(prop.getProperty("productionURL"));
	//	driver.get(prop.getProperty("IntURL"));		
	//	driver.get(prop.getProperty("SITURL"));
		driver.manage().window().maximize();
		
		main1 = new MainScreenObjects(driver);
		home= new HomeScreenObjects(driver);
		/*home.clickOnMainScreenBtn();
		main1.clickOnBookFreeTest();*/
		
		main = new MainScreenObjects_old(driver);
		booktest = new BookFreeTestScreenObjects_old(driver);
		booktest.clickOnAcceptCookies();
		/*booktest.clickOnBookFreeTestNow();*/
		booktest.ClickHavingCoronaSymptom();
	 
	 }


	@When("User select Yes to essential worker")
	public void user_select_yes_to_essential_worker() throws IOException, InterruptedException 
	{
		essentialworker= new EssentialWorkerScreenObjects(driver);
		essentialworker.selectEssentialWorker(prop.getProperty("essentialworkeroptionYes"));
		
	}
	
	@When("User select DontKnow to essential worker")
	public void user_select_dont_know_to_essential_worker() throws IOException, InterruptedException
	{
		essentialworker= new EssentialWorkerScreenObjects(driver);
		essentialworker.selectEssentialWorker(prop.getProperty("essentialworkerdontknow"));
	}
	@When("User has to provide reason for a test")
	public void user_has_to_provide_reason_for_a_test() throws InterruptedException
	{
		booktest.whyAreYouAskingForTest("Local council asked");
	}
	@Then("User select NO to delivery address same as home address")
	public void user_select_no_to_delivery_address_same_as_home_address() 
	{
		booktest.selectYesToHomeAddressSameasDelivery(prop.getProperty("NoToHomeAddressSameasDelivery"));
	}
	@Then("user enter delivery address postcode")
	public void user_enter_delivery_address_postcode() 
	{
	 booktest.enterDeliveryPostCode(prop.getProperty("deliveryPostcode"));
	 booktest.clickonFinddeliveryAddress();
	}
	@Then("user select delivery address from dropdown")
	public void user_select_delivery_address_from_dropdown() 
	{
     booktest.SelectDeliveryAddress(prop.getProperty("deliveryhouseno"));
     
	}
	@Then("User will get notification of kit sent on email and SMS")
	public void user_will_get_notification_of_kit_sent_on_email_and_sms()
	 {
	  
	}
	@Then("User selects currently work status prefer not to say")
	public void user_selects_currently_work_status_prefer_not_to_say() {
	   booktest.currentWorkStatusPreferNotToSay();
	}


	@Then("User select occupation of the person I cannot find correct occupation")
	public void user_select_occupation_of_the_person_i_cannot_find_correct_occupation() throws IOException {
		OccupationScreenObjects occupationscreen=new OccupationScreenObjects(driver);
		occupationscreen.selectOccupationListCannotFind();
		occupationscreen.clickOnContinue();
	}

	@Then("User enters employer of the person na")
	public void user_enters_employer_of_the_person_na() throws IOException {
		EmployerDetailsScreenObjects employerdetails = new EmployerDetailsScreenObjects(driver);
		employerdetails.employerDetails();
	}
	
	@Then("User change the date and time")
	public void user_change_the_date_and_time() {
		booktest.changeAppointmentDateAndTime();
	}
    @Then("User has to select the different time for appointment")
    public void user_has_to_select_the_different_time_for_appointment() throws InterruptedException {
    	booktest.differentAppointmentDateAndTime();
    }
    @Then("User close the window")
    public void User_close_the_window() {
    	booktest.closeWindow();
    }


@Then("Selects I am not robot")
public void selects_i_am_not_robot() 
{
    booktest.clickOnSecuritycheck();

}

@Then("User should get a screen with text Visiting a drive-through test")
public void user_should_get_a_message_no_test_sites_available()
{
    String actual=booktest.getScreenText();
    String toVerify="Visiting a drive-through test site: what you need to know";
    System.out.println("actual "+actual);
    Assert.assertTrue(actual.contains(toVerify));

}

@When("User enter today date in symptoms start date")
public void user_enter_today_date_in_symptoms_start_date() throws InterruptedException
{
	LocalDate date = LocalDate.now().minusDays(0);
	String startdate = Integer.toString(date.getDayOfMonth());
	String startmonth = Integer.toString(date.getMonthValue());
	String startyear = Integer.toString(date.getYear());
	booktest.enterSymptomsStartDate(startdate,startmonth,startyear);
    System.out.println(startdate+startmonth+startyear);
}

@Then("User select ethnic background")
public void user_select_background() throws IOException 
{
	booktest= new BookFreeTestScreenObjects_old(driver);
	booktest.background(prop.getProperty("Pakistani"));

}
@Then("User selects Yes working from home last two weeks to currently in work field")
public void user_selects_yes_working_from_home_last_two_weeks_to_currently_in_work_field() 
{
	booktest.currentWorkStatus(prop.getProperty("currentWorkStatusYesWorkingFromHome"));

}

@Then("user choose time slot for next day for taking test")
public void user_choose_time_slot_for_next_day_for_taking_test() throws InterruptedException
 {
	booktest.clickNextday();
	booktest.selectTimeSlot(prop.getProperty("TimeSlotFirst"));
}


@Then("User selects area of work as Health and social care")
public void user_selects_area_of_work_as_health_and_social_care() 
{
	booktest.areaOfWork(prop.getProperty("workarea1"));   
}


@Then("User selects Health care practice manager in occupation")
public void user_selects_health_care_practice_manager_in_occupation()
{
 booktest.enterOccupation(prop.getProperty("occupationHealthCare"));   
}
@Then("User need to enter the employer name as NHSCare for the person needing a test")
public void user_need_to_enter_the_employer_name_as_nhs_care_for_the_person_needing_a_test()
{
	booktest.enterEmployer(prop.getProperty("employerName"));
}




}