package stepdef;

import java.io.IOException;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.AppRegistrationObjects;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class InstallApp extends InitiateWebBrowser
{
   HomeScreenObjects home;
   MainScreenObjects main;
   AppRegistrationObjects register;
      
   static String APK;
   
	public InstallApp() throws IOException
	{
		super();
		
	}

	@Given("User is provided with apk file")
	public void user_is_provided_with_apk_file() throws IOException 
	{
		APK= prop.getProperty("apk");
		System.out.println("APK is available");
	}

	@When("User execute apk file")
	public void user_execute_apk_file() throws IOException 
	{
		InitiateWebBrowser.initiateWebBrowser();
	}
	@Then("User must be able to install NHS Covid app")
	public void user_must_be_able_to_install_nhs_covid_app() throws IOException 
	{
	  home = new HomeScreenObjects(driver);
	  register = new AppRegistrationObjects(driver);
	  home.clickOnMainScreenBtn();
	  String message= register.getWelcomeMessage();
	  Assert.assertTrue(message.contains("This app helps us keep each other safe"));
	}
	
 
}
