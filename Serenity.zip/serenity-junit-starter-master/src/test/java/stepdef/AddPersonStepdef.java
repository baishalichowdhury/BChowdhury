package stepdef;

import java.io.IOException;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.BookFreeTestScreenObjects_old;
import io.cucumber.java.en.Then;

public class AddPersonStepdef extends InitiateWebBrowser
{

	public AddPersonStepdef() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	BookFreeTestScreenObjects_old booktest;
@Then("User click Add Person you Live with")
public void user_click_add_person_you_live_with() throws IOException 
{
	booktest= new BookFreeTestScreenObjects_old(driver);
	booktest.clickonAddPerson();
}


/*@Then("User has to provide the name details of the next person")
public void user_has_to_provide_the_name_details_of_the_next_person() throws InterruptedException 
{
  booktest.firstNamelastNameScreen(prop.getProperty("firstnameofnextperson"),prop.getProperty("Lastnameofnextperson"));
} */
/*@Then("User enters date of birth of the next person")
public void user_enters_date_of_birth_of_the_next_person()
 {
	String date= prop.getProperty("dateofbirthNext");
	String month= prop.getProperty("monthofbirthNext");
	String year= prop.getProperty("yearofbirthNext");
	booktest.enterDOB(date,month,year);
} */

/*@Then("User has to provide the rough symptoms start date of the next person")
public void user_has_to_provide_the_rough_symptoms_start_date_of_the_next_person() throws InterruptedException 
{
	String startdate = prop.getProperty("startdateNext");
	String startmonth = prop.getProperty("startmonthNext");
	String startyear = prop.getProperty("startyearNext");
	booktest.enterSymptomsStartDate(startdate,startmonth,startyear);
}*/
@Then("User has to provide the mobile number of the next person")
public void user_has_to_provide_the_mobile_number_of_the_next_person() throws InterruptedException
 {
	booktest.enterMobileNumber(prop.getProperty("mobileNumberNext"));
	booktest.ConfirmMobileNumber(prop.getProperty("mobileNumberNext"));
}
@Then("User select No to landline phone number of the next person")
public void user_select_no_to_landline_phone_number_of_the_next_person() throws InterruptedException 
{
	booktest.landlineNotAvailabile();
}
@Then("User has to provide an email address of the next person")
public void user_has_to_provide_an_email_address_of_the_next_person() throws InterruptedException
 {
	booktest.selectEmailoption();
	booktest.enterEmailAddress(prop.getProperty("emailAddressNext"));
}
@Then("User has to provide a Gender detail of the next person")
public void user_has_to_provide_a_gender_detail_of_the_next_person() 
{  
	booktest.selectGender(prop.getProperty("genderNext"));
}
@Then("User has to provide a Ethnic group of the next person")
public void user_has_to_provide_a_ethnic_group_of_the_next_person() 
{
	booktest.enterEthnicityGroup(prop.getProperty("EthnicgroupPreferNottosay"));
}
@Then("User selects currently not in work field of the next person")
public void user_selects_currently_not_in_work_field_of_the_next_person() 
{
	booktest.currentWorkStatus(prop.getProperty("currentWorkStatusNo"));
}
@Then("User has to provide a country of residence of the next person")
public void user_has_to_provide_a_country_of_residence_of_the_next_person() 
{
	booktest.countryOfResidence(prop.getProperty("CountryScotland"));  
}
@Then("User has to provide the postcode of the next person")
public void user_has_to_provide_the_postcode_of_the_next_person() 
{
	booktest.clickPostCodeSameorSomewhereelse(prop.getProperty("homePostcodesDifferent"));	
	booktest.enterDifferentPostcode(prop.getProperty("differentPostcode"));
//	booktest.clickPostCodeSame();
	System.out.println("Post Code entered");
}
@Then("User selects No to knowing NHS number of the next person")
public void user_selects_no_to_knowing_nhs_number_of_the_next_person()
 {
   booktest.nhsnumberAvailability(prop.getProperty("DontKnowNHS"));
}
@Then("User enters No to Know NI Number")
public void user_enters_no_to_know_ni_number()
 {
  booktest.doYouKnowNINumber(prop.getProperty("NoNI"));
}

}
