package stepdef;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.OutcomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.ReviewSymptomsScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.SymptomsCheckerScreenObjects;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SymptomCheckerStepDef extends InitiateWebBrowser 
{
	HomeScreenObjects home;
	MainScreenObjects main;
	SymptomsCheckerScreenObjects symptom;
	ReviewSymptomsScreenObjects review;
	OutcomeScreenObjects outcome;

	
	public SymptomCheckerStepDef() throws IOException 
	{
		super();
		
	}

	
	@Given("User is on the home page of the app")
	public void user_is_on_the_home_page_of_the_app() throws IOException
	{	 
		InitiateWebBrowser.initiateWebBrowser();;
	}

	@When("User click in the main screen button")
	public void user_click_in_the_main_screen_button() throws IOException 
	{
		home= new HomeScreenObjects(driver);
		home.clickOnMainScreenBtn();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@When("User is able to select check symptoms")
	public void user_is_able_to_select_check_symptoms() throws IOException
	{
		main= new MainScreenObjects(driver);
		main.clickOncheckSymptomsbtn();
	}

	@When("User is able to select one symptoms check box")
	public void user_is_able_to_select_one_symptoms_check_box() throws IOException
	{
		symptom= new SymptomsCheckerScreenObjects(driver);
		symptom.marktempCheckbox();
		
	}
	
	@When("User is able to select two symptoms check box")
	public void user_is_able_to_select_two_symptoms_check_box() throws IOException
	{
		symptom= new SymptomsCheckerScreenObjects(driver);
		symptom.marktempCheckbox();
		symptom.markcoughChkBx();
		
	}
	
	@When("User is able to select three symptoms check box")
	public void user_is_able_to_select_three_symptoms_check_box() throws IOException
	{
		symptom= new SymptomsCheckerScreenObjects(driver);
		symptom.marktempCheckbox();
		symptom.markcoughChkBx();
	/*	@SuppressWarnings("rawtypes")
	//	TouchAction ts = new TouchAction(driver); 
		ts.press(point(540, 540)).moveTo(point(540, -100)).release().perform(); 
		//  ts.press(point(540, 540)).moveTo(point(540, 10)).release().perform();
*/		symptom.marksmelltasteLossChkBx();
	}
	
	@When("User select A new loss or change of your sense of smell ot taste")
	public void user_select_a_new_loss_or_change_of_your_sense_of_smell_ot_taste() throws InterruptedException, IOException
	{
	  symptom= new SymptomsCheckerScreenObjects(driver);
	  main.swipeToBottom();
	  symptom.marksmelltasteLossChkBx();
	}

	@SuppressWarnings("rawtypes")
	@When("User is able to click on Continue button")
	public void user_is_able_to_click_on_continue_button() throws InterruptedException 
	{	
		/*new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
		new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();*/
		symptom.clickcontinueBtn();
	}
	
	@When("User should be able to review symptoms")
	public void User_should_be_able_to_review_symptoms() throws InterruptedException, IOException
	{
		review = new ReviewSymptomsScreenObjects(driver);
    	System.out.println("Title review symptom : " + review.getTextOfreviewSymptoms());
    	Assert.assertEquals("Review your answers", review.getTextOfreviewSymptoms());
	}
   
	
	@SuppressWarnings("rawtypes")
	@When("user select I dont remember date checkbox")
	public void user_select_i_dont_remember_date_checkbox() 
	{
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
		review.selectunknownDate();
	}

	@SuppressWarnings("rawtypes")
	@When("click on submit")
	public void click_on_submit() throws InterruptedException
	{   
        MainScreenObjects.swipeToBottom();
		review.clickSubmit();
	}
	 
	
	@Then("User must be able to see the result on the basis of symptoms selected")
	public void user_must_be_able_to_see_the_result_on_the_basis_of_symptoms_selected() throws InterruptedException, IOException
	{
		outcome = new OutcomeScreenObjects(driver);
		System.out.println("Self isolation days: " + outcome.getTextOnResultScreen());
		Assert.assertEquals("8 days", outcome.getTextOnResultScreen());
		driver.close();
	}
	
	@Then("User can see the Self-isolate for eight days and book a test")
	public void user_can_see_the_self_isolate_for_eight_days_and_book_a_test() throws IOException
	{
		outcome = new OutcomeScreenObjects(driver);
		Assert.assertEquals("Self-isolate for 8 days and book a test", outcome.getTextOnResultScreen());
		
	}
	
	@Then("User click on cancel")
	public void user_click_on_cancel()
	{
		outcome.clickOnCancelBtn();
	}
	
	@Then("User can see message You need to self-isolate until TodaysDate plus seven days")
	public void user_can_see_message_you_need_to_self_isolate_until_todays_date_plus_eight_days() throws IOException 
	{
		main= new MainScreenObjects(driver);
	    String futuredate= main.getFutureDaysDate(7);
	    String m=main.selfIsolationMessage();
       String toVerify = "You need to self-isolate until "+futuredate+" at 23:59";
       Assert.assertTrue(m.contains(toVerify));
	}
	
	@Then("Self referal portal should get open")
	public void self_referal_portal_should_get_open() throws InterruptedException
	{
      main.switchContext();
      String bookurl=driver.getCurrentUrl();
      String expected= prop.getProperty("ExpectedURL");
      Assert.assertEquals(expected,bookurl);
	}
	
	@When("User select todays date in Symptom start date field")
	public void user_select_todays_date_in_symptom_start_date_field() throws IOException 
	{
		review = new ReviewSymptomsScreenObjects(driver);
		review.selectDate(0);
	}

	@Then("User can see the Self-isolate for ten days and book a test")
	public void user_can_see_the_self_isolate_for_ten_days_and_book_a_test() throws IOException 
	{
		outcome = new OutcomeScreenObjects(driver);
		Assert.assertEquals("Self-isolate for 10 days and book a test", outcome.getTextOnResultScreen());

	}
	@Then("User can see message You need to self-isolate until TodaysDate plus nine days")
	public void user_can_see_message_you_need_to_self_isolate_until_todays_date_plus_ten_days() throws IOException 
	{
		main= new MainScreenObjects(driver);
	    String futuredate= main.getFutureDaysDate(9);
        String m=main.selfIsolationMessage();
        String toVerify = "You need to self-isolate until "+futuredate+" at 23:59";
        Assert.assertTrue(m.contains(toVerify));
	}
	
	@When("User select Past 5days date in Symptom start date field")
	public void user_select_past_5days_date_in_symptom_start_date_field() throws IOException 
	{
		review = new ReviewSymptomsScreenObjects(driver);
		review.selectDate(5);
	}

	@Then("User can see the Self-isolate for five days and book a test")
	public void user_can_see_the_self_isolate_for_five_days_and_book_a_test() throws IOException  
	{
		outcome = new OutcomeScreenObjects(driver);
		Assert.assertEquals("Self-isolate for 5 days and book a test", outcome.getTextOnResultScreen());
	}

	@Then("User can see message You need to self-isolate until TodaysDate plus four days")
	public void user_can_see_message_you_need_to_self_isolate_until_todays_date_plus_four_days() throws IOException 
	{
		main= new MainScreenObjects(driver);
		String futuredate= main.getFutureDaysDate(4);		
	    String m=main.selfIsolationMessage();
	    String toVerify = "You need to self-isolate until "+futuredate+" at 23:59";
	    Assert.assertTrue(m.contains(toVerify));
	}
	
	
}
