package stepdef;

import java.io.IOException;

import org.junit.Assert;

import com.google.common.base.Verify;

import DempProject.base.InitiateWebBrowser;
import DempProject.base.JSONDataReader;
import gov.dhsc.qat.nhstt.pageobjects.BookFreeTestScreenObjects_old;
import gov.dhsc.qat.nhstt.pageobjects.EssentialWorkerScreenObjects;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import testDataTypes.User;

public class BookTestDataDrivenStepDef extends InitiateWebBrowser
{
	BookFreeTestScreenObjects_old booktest;
	EssentialWorkerScreenObjects essential;

	public BookTestDataDrivenStepDef() throws IOException
	{
		super();
	
	}
	
	@When("User enter all the required detail")
	public void user_enter_all_the_required_detail() throws IOException, InterruptedException 
	{
		booktest= new BookFreeTestScreenObjects_old(driver);
		essential = new EssentialWorkerScreenObjects(driver);
		User cust= JSONDataReader.getValueByUserId("sc2014tc001","User.json");
		booktest.enterSymptomsStartDate(cust.symptomstartdate, cust.symptomstartmonth, cust.symptomstartyear);
		essential.selectEssentialWorker(cust.essentialworker);
	//	booktest.partOfTrialOrGovernmentProject(cust.partofpilotproject);
	//	Thread.sleep(5000);
		booktest.firstNamelastNameScreen(cust.firstName, cust.lastName);
		booktest.selectMobile(cust.havingmobileno);
		booktest.enterMobileNumber(cust.mobileno);
		booktest.selectEmailoption(cust.haveemail);
		booktest.enterEmailAddress(cust.email);
		booktest.enterPostcode(cust.postcode);
		booktest.vehicleAccess(cust.vehicleaccess);
		booktest.ClickonConfirmandcontinue();
		booktest.checkSelectedAnswers();
		booktest.clickOnDriveThroughSite();
		String actual= booktest.getScreenText();
		String toverify="Visiting a drive-through test site: what you need to know";
		//Verify.verify(actual.contains(toverify));
		Assert.assertTrue(actual.contains(toverify));
		booktest.clickContinue();
		booktest.enterDOB(cust.dayofbirth, cust.monthofbirth, cust.yearofbirth);
		booktest.landlineNotAvailabile();
		booktest.selectGender(cust.gender);
		booktest.enterEthnicityGroup(cust.ethnicgroup);
		booktest.background(cust.ethnicbackground);
		booktest.currentWorkStatus(cust.currentlyinwork);
		booktest.countryOfResidence(cust.country);
		booktest.nhsnumberAvailability(cust.knowNHS);
		booktest.clickonSaveAndContinueAns();
		booktest.ClickonSaveAndcontinue();
		booktest.clickOnContinue();
		booktest.chooseTestSite(cust.testsite);
		booktest.selectTimeSlot(cust.timeslot);
		booktest.vehicleRegistrationNumber(cust.vehicleregistrationno);
		booktest.validateAppointmentConfirmationMessage();
		booktest.confirmAppointmentDetails();

		
	}


	@Then("Appointment should be booked")
	public void appointment_should_be_booked()
	{
		booktest.VerifyAppointmentBookedText();
	}
	
// to be run in int environment	
	@When("User enter all the required detail accordingly")
	public void user_enter_all_the_required_detail_accordingly() throws IOException, InterruptedException
	 {
		booktest= new BookFreeTestScreenObjects_old(driver);
		essential = new EssentialWorkerScreenObjects(driver);
		User cust= JSONDataReader.getValueByUserId("sc2011tc001","User.json");
		booktest.enterSymptomsStartDate(cust.symptomstartdate, cust.symptomstartmonth, cust.symptomstartyear);
		essential.selectEssentialWorker(cust.essentialworker);
		//booktest.partOfTrialOrGovernmentProject(cust.partofpilotproject);
		Thread.sleep(5000);
		booktest.firstNamelastNameScreen(cust.firstName, cust.lastName);
		booktest.selectMobile(cust.havingmobileno);
		booktest.enterMobileNumber(cust.mobileno);
		booktest.selectEmailoption(cust.haveemail);
		booktest.enterEmailAddress(cust.email);
		booktest.enterPostcode(cust.postcode);
		booktest.vehicleAccess(cust.vehicleaccess);
		booktest.ClickonConfirmandcontinue();
		booktest.checkSelectedAnswers();
		
	}

	@Then("Walk-through test site radio button is read only")
	public void walk_through_test_site_radio_button_is_read_only()
	 {
	   Boolean b=booktest.drivethroughoptionavailability();
	   Assert.assertFalse(b);
	}

	@Then("Text is no appointment available at walk-through")
	public void text_is_no_appointment_available_at_walk_through() 
	{
     String actual= booktest.getDriveThroughText();
     String toVerify="There are currently no appointments available. Please try again in a few hours.";
     Assert.assertTrue(actual.contains(toVerify));
	}


}
