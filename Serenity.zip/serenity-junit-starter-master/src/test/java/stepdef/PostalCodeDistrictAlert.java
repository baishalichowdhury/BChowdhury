package stepdef;

import java.io.IOException;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.RiskLevelScreenObjects;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class PostalCodeDistrictAlert extends InitiateWebBrowser
{
	HomeScreenObjects home;
	RiskLevelScreenObjects risk;
	MainScreenObjects main;
	
	public PostalCodeDistrictAlert() throws IOException
	{
		super();
	}
	
	@Given("^User has done the registration in Covid App with the area postcode having low risk$")
	public void user_has_done_the_registration_in_covid_app_with_low_risk_area_postcode () 
	{
	 System.out.println("involve app registration test case");
	}
	
	@Given("^User has done the registration in Covid App with the area postcode having medium risk$")
	public void user_has_done_the_registration_in_covid_app_with_medium_risk_area_postcode () 
	{
	 System.out.println("involve app registration test case");
	}
	
	@Given("^User has done the registration in Covid App with the area postcode having high risk$")
	public void user_has_done_the_registration_in_covid_app_with_high_risk_area_postcode (String Postcode) 
	{
	 System.out.println("involve app registration test case");
	}

	
	
	@When("User Logs into the App")
	public void user_logs_into_the_app() throws IOException 
	{
		
		InitiateWebBrowser.initiateWebBrowser();
	}
	@Then("^User can see the District risk Alert as ([^\"]*) on the main screen$")
	public void user_can_see_the_district_risk_alert_on_the_main_screen(String Color) throws IOException, InterruptedException 
	{
		home= new HomeScreenObjects(driver);
	    home.clickOnMainScreenBtn();
	    home.waitMethod();
	    main= new MainScreenObjects(driver);
	    String colourOfAlert=main.getColorOfRiskLevelStatus();
	    Assert.assertEquals(Color, colourOfAlert);
    }
	
	@Then("^User can see the District risk Alert in Red color$")
	public void user_can_see_the_district_risk_alert_red_color() throws IOException, InterruptedException 
	{
		home= new HomeScreenObjects(driver);
	    home.clickOnMainScreenBtn();
	    home.waitMethod();
	    main= new MainScreenObjects(driver);
	    String colourOfAlert=main.getColorOfRiskLevelStatus();
	    Assert.assertEquals("Red", colourOfAlert);
    }
	
	@Then("^User can see the District risk Alert in Green color$")
	public void user_can_see_the_district_risk_alert_green_color() throws IOException, InterruptedException 
	{
		home= new HomeScreenObjects(driver);
	    home.clickOnMainScreenBtn();
	    home.waitMethod();
	    main= new MainScreenObjects(driver);
	    String colourOfAlert=main.getColorOfRiskLevelStatus();
	    Assert.assertEquals("Green", colourOfAlert);
    }
	
	@Then("^User can see the District risk Alert in Amber color$")
	public void user_can_see_the_district_risk_alert_Amber_color() throws IOException, InterruptedException 
	{
		home= new HomeScreenObjects(driver);
	    home.clickOnMainScreenBtn();
	    home.waitMethod();
	    main= new MainScreenObjects(driver);
	    String colourOfAlert=main.getColorOfRiskLevelStatus();
	    Assert.assertEquals("Amber", colourOfAlert);
    }
	
}
