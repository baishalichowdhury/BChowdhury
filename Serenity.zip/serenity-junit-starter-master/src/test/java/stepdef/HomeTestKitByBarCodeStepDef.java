package stepdef;

import java.io.IOException;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.BookFreeTestScreenObjects_old;
import gov.dhsc.qat.nhstt.pageobjects.HomeKitRegistrationScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects_old;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class HomeTestKitByBarCodeStepDef extends InitiateWebBrowser
{

	MainScreenObjects main1;
	HomeScreenObjects home;
	MainScreenObjects_old main;
	BookFreeTestScreenObjects_old booktest;
public HomeTestKitByBarCodeStepDef() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

@Given("User enter URL to register home test kit")
public void user_enter_url_to_register_home_test_kit() throws IOException, InterruptedException 
{
	InitiateWebBrowser.initiateWebBrowser();
//	driver.get("https://npd-sit-1-sp.sit.bluesquirrelproject.net/register-home-test");
	driver.get(prop.getProperty("HomeKitSITURL"));
	driver.manage().window().maximize();

	main1 = new MainScreenObjects(driver);
	home= new HomeScreenObjects(driver);
	main = new MainScreenObjects_old(driver);
	booktest = new BookFreeTestScreenObjects_old(driver);
	booktest.clickOnAcceptCookies();
 
}

@Given("User enter URL to lite register home test kit")
public void user_enter_url_to_lite_register_home_test_kit() throws IOException, InterruptedException 
{
	InitiateWebBrowser.initiateWebBrowser();
	 driver.get(prop.getProperty("HomeKitLiteSITURL"));
	driver.manage().window().maximize();
	main1 = new MainScreenObjects(driver);
	home= new HomeScreenObjects(driver);
	main = new MainScreenObjects_old(driver);
	booktest = new BookFreeTestScreenObjects_old(driver);
	booktest.clickOnAcceptCookies();
 
}

@Given("User enter URL for Lite regitration")
public void user_enter_URL_for_Lite_regitration() throws IOException
{
	InitiateWebBrowser.initiateWebBrowser();
//	driver.get("https://npd-int-1-sp.int.bluesquirrelproject.net/register-kit");
	driver.get("https://npd-sit-1-sp.sit.bluesquirrelproject.net/register-kit");
	driver.manage().window().maximize();
	main1 = new MainScreenObjects(driver);
	home= new HomeScreenObjects(driver);
	main = new MainScreenObjects_old(driver);
	booktest = new BookFreeTestScreenObjects_old(driver);
	booktest.closeCookies();	
	booktest.selectStartNowRegisterKitJourney();
}


@When("User clicks on Start Now on Register a home test kit")
public void user_clicks_on_start_now_on_register_a_home_test_kit() 
{
	booktest.clickOnStartNow();
}
@When("User select Yes to Knowing how to return your test kit")
public void user_select_yes_to_knowing_how_to_return_your_test_kit()
 {
   booktest.ClickKnowReturnTestKit();
}
@When("User clicks on link register your kit a different way on the page of What's your orderid")
public void user_clicks_on_link_register_your_kit_a_different_way_on_the_page_of_what_s_your_orderid() 
{
   booktest.clickonDifferentWaylink();
}
@When("User clicks on start now on the page of Registering a coronavirus test")
public void user_clicks_on_start_now_on_the_page_of_registering_a_coronavirus_test() 
{
	main1.switchWindowTab();
	booktest.clickOnStartNow();
 }
@When("User selects At a test site to where taking test")
public void user_selects_at_a_test_site_to_where_taking_test() 
{
  booktest.whereToTakeTest(prop.getProperty("testLocation"));
}
@When("User enters order id")
public void user_enters_order_id() throws InterruptedException, IOException
{
	HomeKitRegistrationScreenObjects hometestkit = new HomeKitRegistrationScreenObjects();
//	String orderid = prop.getProperty("orderid");
	hometestkit.enterOrderId();
}
@When("User enter postcode of the test site")
public void user_enter_postcode_of_the_test_site() throws InterruptedException 
{
	
	booktest.AddPostcodeOfTestSite(prop.getProperty("postcodetobboktest"));	
}
@When("User select nearest test site")
public void user_select_nearest_test_site() throws InterruptedException 
{
//   booktest.whereToTakeTest1(prop.getProperty("AtTestSite")); 
    booktest.chooseTestSite(prop.getProperty("NearestTestSite"));
   // booktest.chooseTestSite();
 
}
@When("User enter unique test kit barcode number")
public void user_enter_unique_test_kit_barcode_number()
 {
	String barcode= prop.getProperty("barcode");
    booktest.EnterBarCode(barcode);
	booktest.confirmBarCode(barcode);

}
@When("User selects date and time of taking coronavirus test")
public void user_selects_date_and_time_of_taking_coronavirus_test() throws InterruptedException 
{
   booktest.selectTimeTotaketest();
   booktest.timeOfTakingTest(prop.getProperty("timeOfTakingTest"));
   booktest.clickampm(prop.getProperty("pm"));

}
@When("User selects different date and time")
public void user_selects_different_date_and_time() {
    booktest.selectDifferentTimeToTakeTest();
    booktest.testDateInput();
    booktest.timeOfTakingTest("3");
    booktest.clickpm();
}

@When("User enters date of birth")
public void user_enters_date_of_birth() 
{
	String date= prop.getProperty("dateofbirth");
	String month= prop.getProperty("monthofbirth");
	String year= prop.getProperty("yearofbirth");
	booktest.enterDOB(date,month,year);
}
@When("User select Asian or Asian British Ethnic group")
public void user_select_asian_or_asian_british_ethnic_group() 
{
 booktest.enterEthnicityGroup(prop.getProperty("EthnicgroupAsian"));
 booktest.background(prop.getProperty("background"));
}

@When("User has to provide a country of residence England")
public void user_has_to_provide_a_country_of_residence_England() {
    booktest.countryOfResidence(prop.getProperty("CountryEngland"));
}

@When("User has to provide the mobile number and confirm it")
public void user_has_to_provide_the_mobile_number_and_confirm_it() throws InterruptedException 
{
	booktest.enterMobileNumber(prop.getProperty("mobileNumberNext"));
	booktest.ConfirmMobileNumber(prop.getProperty("mobileNumberNext"));
}

@When("User selects No to knowing NHS number")
public void user_selects_no_to_knowing_nhs_number() throws IOException 
{
 booktest= new BookFreeTestScreenObjects_old(driver);
 booktest.nhsnumberAvailability(prop.getProperty("NHSDontKnow"));
}
@When("clicks on Save and continue")
public void clicks_on_save_and_continue() 
{
    booktest.clickonSaveAndContinueAns();
}
@When("User clicks on I am not robot")
public void user_clicks_on_i_am_not_robot() 
{
   System.out.println("waiting for security check");
}
@Then("User gets Registration Confirmed message")
public void user_gets_registration_confirmed_message() 
{
   String ConfirmationMessage=booktest.TestKitRegistrationConfirmationMessage();
   String ToConfirm="Registration Confirmed";
   Assert.assertTrue(ConfirmationMessage.contains(ToConfirm));
}



}
