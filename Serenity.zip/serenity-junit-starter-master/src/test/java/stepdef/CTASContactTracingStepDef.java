package stepdef;

import java.io.IOException;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.CTASAboutHealthScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASAboutYouScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASContactFeedbackScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASIsolationInformationScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASVulnerableMarkersScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASLoginScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASWelcomeScreenObjets;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CTASContactTracingStepDef extends InitiateWebBrowser
{

	public CTASContactTracingStepDef() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	
CTASLoginScreenObjects CTASLogin;
CTASWelcomeScreenObjets CTASWelcome;
CTASAboutYouScreenObjects aboutYou;
CTASAboutHealthScreenObjects aboutHealth;
CTASIsolationInformationScreenObjects isolationinformation;
CTASVulnerableMarkersScreenObjects selfIsolate;
CTASContactFeedbackScreenObjects feedback;

@Given("User open link and SignIn with account ID and Password")
public void user_open_link_and_sign_in_with_account_id_and_password() throws IOException, InterruptedException 
{
	InitiateWebBrowser.initiateWebBrowser();
	driver.get(prop.getProperty("CTASContactTracingURL"));
	driver.manage().window().maximize();
	CTASLogin = new CTASLoginScreenObjects(driver);	
	CTASLogin.clickOnSignInBtn();
	Thread.sleep(2000);
	CTASLogin.signIn(prop.getProperty("CTASContactAccountID"), prop.getProperty("CTASContactPassword"));
	

}

@When("User selects Someone else")
public void user_selects_someone_else() throws IOException 
{
	CTASWelcome = new CTASWelcomeScreenObjets(driver);
	CTASWelcome.selectSomeoneElse();

}
@When("Enter first name last name house number postcode")
public void enter_first_name_last_name_house_number_postcode() 
{
	CTASWelcome.enterProxyFirstName(prop.getProperty("CTASProxyFirstName"));
	CTASWelcome.enterProxyLastName(prop.getProperty("CTASProxyLastName"));
	CTASWelcome.enterProxyHouseNo(prop.getProperty("CTASProxyHouseNo"));
	CTASWelcome.enterProxyPostCode(prop.getProperty("CTASProxyPostCode"));
	CTASWelcome.clickOnContinueFromWelcome();

}
@When("Enter details under About You")
public void enter_details_under_about_you() throws IOException
{
	aboutYou = new CTASAboutYouScreenObjects(driver);
	aboutYou.enterFirstName(prop.getProperty("CTASContactFirstName"));
	aboutYou.enterLastName(prop.getProperty("CTASContactLastName"));
	aboutYou.enterDateOfBirth(prop.getProperty("CTASContactDateOfBirth"), prop.getProperty("CTASContactMonthOfBirth"), prop.getProperty("CTASContactYearOfBirth"));
//	aboutYou.selectEthnicity(prop.getProperty(""));
	aboutYou.enterNHSNumber(prop.getProperty("CTASContactNHSNumber"));
	aboutYou.selectGender(prop.getProperty("CTASContactGender"));
	aboutYou.enterHouseNumber(prop.getProperty("CTASContactHouseNo"));
	aboutYou.enterPostCode(prop.getProperty("CTASContactPostCode"));
	aboutYou.selectCurrentAddressSameAsHomeAddress();
	aboutYou.entercontinueFromAboutUs();

}

@When("Enter contact details under About You for SC1010_TC011")
public void enter_contact_details_under_about_you_for_sc1010_tc011() throws IOException 
{
	aboutYou = new CTASAboutYouScreenObjects(driver);
	aboutYou.enterFirstName(prop.getProperty("SC1010_TC011CTASContactFirstName"));
	aboutYou.enterLastName(prop.getProperty("SC1010_TC011CTASContactLastName"));
	aboutYou.enterDateOfBirth(prop.getProperty("SC1010_TC011CTASContactDateOfBirth"), prop.getProperty("SC1010_TC011CTASContactMonthOfBirth"), prop.getProperty("SC1010_TC011CTASContactYearOfBirth"));
//	aboutYou.selectEthnicity(prop.getProperty(""));
	aboutYou.enterNHSNumber(prop.getProperty("SC1010_TC011CTASContactNHSNumber"));
	aboutYou.selectGender(prop.getProperty("SC1010_TC011CTASContactGender"));
	aboutYou.enterHouseNumber(prop.getProperty("SC1010_TC011CTASContactHouseNo"));
	aboutYou.enterPostCode(prop.getProperty("SC1010_TC011CTASContactPostCode"));
	aboutYou.selectCurrentAddressSameAsHomeAddress();
	aboutYou.entercontinueFromAboutUs();
}

@When("User selects A new continuous cough and High temperature")
public void user_selects_a_new_continuous_cough_and_high_temperature() throws IOException 
{
	aboutHealth= new CTASAboutHealthScreenObjects(driver);
	aboutHealth.selectContinousCough();
	aboutHealth.selectHighTemp();
	aboutHealth.enterSymptomStartdate(prop.getProperty(""),prop.getProperty(""),prop.getProperty(""));
	CTASWelcome.clickOnContinueFromWelcome();

}
@When("User clicks on Continue on the screen Please stay at home")
public void user_clicks_on_continue_on_the_screen_please_stay_at_home() 
{
	CTASWelcome.clickOnContinueFromWelcome();

}
@When("User selects None of these apply")
public void user_selects_none_of_these_apply() throws IOException 
{
	selfIsolate= new CTASVulnerableMarkersScreenObjects(driver);
	selfIsolate.selectNoneOfThese();
	CTASWelcome.clickOnContinueFromWelcome();

}
@Then("User get message Thank you fo providing this information")
public void user_get_message_thank_you_fo_providing_this_information() {
//need to put assert over here

}


@When("User selects Myself")
public void user_selects_myself() throws IOException, InterruptedException 
{
	CTASWelcome = new CTASWelcomeScreenObjets(driver);
	Thread.sleep(1000);
	CTASWelcome.selectMyself();
	CTASWelcome.clickOnContinueFromWelcome();
    
}

@When("User selects none of these under tell us about your health")
public void user_selects_none_of_these_under_tell_us_about_your_health() throws IOException, InterruptedException 
{
	Thread.sleep(1000);
	aboutHealth= new CTASAboutHealthScreenObjects(driver);
	aboutHealth.selectNoneOfThese();
	CTASWelcome.clickOnContinueFromWelcome();
    
}
@When("User clicks on Continue on the screen You are required to stay at home")
public void user_clicks_on_continue_on_the_screen_you_are_required_to_stay_at_home() throws IOException, InterruptedException 
{
	Thread.sleep(1000);
    isolationinformation = new CTASIsolationInformationScreenObjects(driver);
    String actual= isolationinformation.getIsolationMessage();
    String toVerify="You are required to stay at home (self-isolate) to keep yourself and others safe";
    Assert.assertTrue(actual.contains(toVerify));
    CTASWelcome.clickOnContinueFromWelcome();
}
@When("User select none of these apply on the screen You have been advised to self-isolate")
public void user_clicks_on_continue_on_the_screen_you_have_been_advised_to_self_isolate() throws IOException, InterruptedException 
{
	Thread.sleep(1000);
	selfIsolate= new CTASVulnerableMarkersScreenObjects(driver);
	String actual= selfIsolate.getSelfIsolateMessage();
	String toVerify="You have been advised to self-isolate – help is available for you";
	Assert.assertTrue(actual.contains(toVerify));
	selfIsolate.selectNoneOfThese();
	CTASWelcome= new CTASWelcomeScreenObjets(driver);
	CTASWelcome.clickOnContinueFromWelcome();
    
}
@Then("User get a message Thank you for providing this information")
public void user_get_a_message_thank_you_for_providing_this_information() throws IOException, InterruptedException 
{
	Thread.sleep(1000);
	feedback = new CTASContactFeedbackScreenObjects(driver);
    String actual= feedback.getThankYouPageMessage();
    String toVerify= "Thank you for providing this information. If we need further information, we will contact you";
    Assert.assertTrue(actual.contains(toVerify));
   // CTASLogin.signOut();
}


}
