package stepdef;

import java.io.IOException;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.AppRegistrationObjects;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegisterIntoNHSCovidApp extends InitiateWebBrowser
{
	HomeScreenObjects home;
	AppRegistrationObjects register;
	MainScreenObjects main;
	public RegisterIntoNHSCovidApp() throws IOException 
	{
		super();
	}

	@Given("A subject has access to NHS Covid App")
	public void a_subject_has_access_to_nhs_covid_app() throws IOException
	{
		System.out.println("Different test case to install app");
	}

	@When("Subject open the app")
	public void subject_open_the_app() throws IOException 
	{
		InitiateWebBrowser.initiateWebBrowser();
	}

	@When("click on continue")
	public void click_on_continue() throws IOException 
	{
		home = new HomeScreenObjects(driver);
		register = new AppRegistrationObjects(driver);
	   home.clickOnMainScreenBtn();
	   register.clickOnContinue();
	   
	}
	@When("Select i am above sixteen")
	public void select_i_am_above() throws InterruptedException 
	{
	   register.selectAbovesixteen();
	}
	@When("click on I agree")
	public void click_on_i_agree() throws InterruptedException, IOException
	{
		main= new MainScreenObjects(driver);
		main.swipeToBottom();
		main.swipeToBottom();
		register.clickOnIAgree();
	}
	@When("Enter Postcode")
	public void enter_postcode() throws InterruptedException 
	{
	  main.swipeToBottom();
      register.enterPostCode(prop.getProperty("postcode"));
	}
	@When("click on Continue")
	public void click_on_continue_after_postcode() 
	{
	 register.PostCodeContinue();
	 register.ContinueContactTrace();
	}
	@When("on pop select Turn On")
	public void on_pop_select_turn_on() throws InterruptedException 
	{
     register.selectTurnOn();
     
	}
	
	@Then("Subject can see the District risk Alert as LOW\\/MEDIUM\\/HIGH on the main screen")
	public void subject_can_see_the_district_risk_alert_as_low_medium_high_on_the_main_screen() throws InterruptedException 
	{
		 Thread.sleep(2000);
		 String risk=main.getRiskLevel();
	     Assert.assertTrue(risk.contains("risk level"));
	     driver.close();
	}
	
	
	@When("Select i am below sixteen")
	public void select_i_am_below_sixteen() throws InterruptedException
	 {
	   register.selectBelowSixteen();
	}


	@Then("Subject can see Unfortunately, you can't run this app screen")
	public void subject_can_see_unfortunately_you_can_t_run_this_app_screen() 
	{
      String message= register.getMessageBelow16();
      Assert.assertTrue(message.contains("Unfortunately, this app is only for people aged 16 years or over"));
      driver.close();
	}
	
	@Then("Subject can see This app helps us keep each other safe")
	public void subject_can_see_Subject_can_see_This_app_helps_us_keep_each_other_safe() 
	{
      String message= register.NoThanksMessage();
      Assert.assertTrue(message.contains("This app helps us keep each other safe"));
      driver.close();
	}
	
	@When("click on No Thanks")
	public void click_on_no_thanks() throws InterruptedException 
	{
	  main.swipeToBottom();
	  main.swipeToBottom();
      register.clickOnNoThanks();
	}

}