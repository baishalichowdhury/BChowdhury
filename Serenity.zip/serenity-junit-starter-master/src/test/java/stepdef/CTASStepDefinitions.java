package stepdef;

import java.io.IOException;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.BookFreeTestScreenObjects_old;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects_old;
import gov.dhsc.qat.nhstt.pageobjects.TracingPortalScreenObjects;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class CTASStepDefinitions extends InitiateWebBrowser {
	
	MainScreenObjects main1;
	HomeScreenObjects home;
	MainScreenObjects_old main;
	BookFreeTestScreenObjects_old booktest;
	TracingPortalScreenObjects tracingportal;

	public CTASStepDefinitions() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Given("User enter tracing portal URL")
	public void user_is_on_the_web_portal() throws IOException, InterruptedException
	 {
		InitiateWebBrowser.initiateWebBrowser();
		driver.get("https://contact-tracing.testing.phe.gov.uk");
		driver.manage().window().maximize();
		main1 = new MainScreenObjects(driver);
		home= new HomeScreenObjects(driver);
		main = new MainScreenObjects_old(driver);
		booktest = new BookFreeTestScreenObjects_old(driver);
//		booktest.closeCookies();
		tracingportal = new TracingPortalScreenObjects(driver);
		tracingportal.selectSignIn();
	 
	 }
	@When("User enters credentials and signin")
	public void user_enters_credentials_and_signin() {
	    
	    String accid=prop.getProperty("accountid");
		String pw=prop.getProperty("password");
		tracingportal.enterCredentials(accid,pw);
	    System.out.println("stepran");
	}
	@When("User selects Myself button")
	public void user_selects_myself_button() {
		tracingportal.selectMyself();
	}
	@When("User enter details of the person")
	public void user_enter_details_of_the_person() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@When("User selects symptoms details")
	public void user_selects_symptoms_details() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
}
