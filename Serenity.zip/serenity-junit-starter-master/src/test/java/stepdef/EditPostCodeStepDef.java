package stepdef;

import java.io.IOException;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.AboutThisAppScreenObject;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.ManageMyDataScreenObjects;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EditPostCodeStepDef extends InitiateWebBrowser
{
	public EditPostCodeStepDef() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	MainScreenObjects main;
	AboutThisAppScreenObject aboutapp;
	ManageMyDataScreenObjects manageData;
	
	@When("User is able to click on About this app Button")
	public void user_is_able_to_click_on_about_this_app_button() throws IOException, InterruptedException 
	{
	  main= new MainScreenObjects(driver);
	  main.swipeToBottom();
      main.clickOnAboutThisAppBtn();
	  
	}
	
	@When("User is able to click on link Manage my data")
	public void user_is_able_to_click_on_link_manage_my_data() throws InterruptedException, IOException
	{ 
		main.swipeToBottom();
		aboutapp = new AboutThisAppScreenObject(driver);
		aboutapp.clickOnManageMyData();
     
	}
	@When("User is able to click on Edit postcode button")
	public void user_is_able_to_click_on_edit_postcodet_button() throws IOException 
	{
       manageData = new ManageMyDataScreenObjects(driver);
       manageData.clickOnEditPostcode();
	}
	@When("User should be able to Enter new PostCode and click on save button")
	public void user_should_be_able_to_enter_new_post_code_and_click_on_save_button() 
	{
		manageData.EditpostCode(prop.getProperty("editpostcode"));
		manageData.clickOnSavePostcode();
	}
	@When("User close the app and open it again")
	public void user_close_the_app_and_open_it_again() throws IOException 
	{
       driver.close();
       InitiateWebBrowser.initiateWebBrowser();
	}
	@Then("User must be able to see the updated postcode on home screen")
	public void user_must_be_able_to_see_the_updated_postcode_on_home_screen() throws IOException, InterruptedException 
	{
	  main= new MainScreenObjects(driver);
      main.clickOnMainScreenBtn();
      String toVerify= prop.getProperty("editpostcode")+" area risk level is";
      String homeRiskAlert = main.getRiskLevel();
      Assert.assertTrue(homeRiskAlert.contains(toVerify));
	}
}
