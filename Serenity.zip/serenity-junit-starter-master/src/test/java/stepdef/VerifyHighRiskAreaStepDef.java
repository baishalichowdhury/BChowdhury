package stepdef;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.RiskLevelScreenObjects;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

@SuppressWarnings("deprecation")
public class VerifyHighRiskAreaStepDef extends InitiateWebBrowser
{
	
	HomeScreenObjects home;
	MainScreenObjects main;
	RiskLevelScreenObjects risklevel;
	
	public VerifyHighRiskAreaStepDef() throws IOException
	{
		super();
	}

@Given("the user is on the home page of the app")
public void the_user_is_on_the_home_page_of_the_app() throws IOException 
{ 
	InitiateWebBrowser.initiateWebBrowser();
}

@When("the user clicks Main button")
public void the_user_clicks_main_button() throws IOException 
{
	home= new HomeScreenObjects(driver);
	home.clickOnMainScreenBtn();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
   
}
@SuppressWarnings("rawtypes")
@When("then he clicks on Risky PostCode botton")
public void then_he_clicks_on_risky_post_code_botton() throws InterruptedException, IOException
{
	main = new MainScreenObjects(driver);
	main.swipeToBottom();
	main.swipeToBottom();
	main.swipeToBottom();
    main.clickRiskyPostcodebtn();
	
}


@Then("User clicks on the the Label stating risk message")
public void user_clicks_on_the_the_label_stating_risk_message() 
{
  main.clickOnriskLevelStatus();
}

@Then("User get message of risk HIGH")
public void user_get_message_of_risk_high() throws IOException
{
    risklevel = new RiskLevelScreenObjects(driver);
    String RiskMessage= risklevel.getTextRiskLevelMessage();
    Boolean bol= RiskMessage.contains("HIGH");
    Assert.assertTrue(bol);
}

@Then("user is able to close risk message")
public void user_is_able_to_close_risk_message() 
{
	risklevel.closeriskLevelMessage();
	driver.close();
   
}
	
}