package stepdef;

import java.io.IOException;
import java.time.LocalDate;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.CTASAboutHealthScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASAboutYouScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASActivitiesOutSideScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASAnyActivitiesYouDid;
import gov.dhsc.qat.nhstt.pageobjects.CTASContactFeedbackScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASDidYouLeaveHomeScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASIsolationInformationScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASLoginScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASMoreAboutWhereYouLiveObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASNewPersonDetailScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASStayOverNightScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASThankYouScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASVulnerableMarkersScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASWelcomeScreenObjets;
import gov.dhsc.qat.nhstt.pageobjects.CTASWhereCaughtCovid;
import gov.dhsc.qat.nhstt.pageobjects.CTASWhereYouLiveScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASWhoYouLiveWithScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASWorkOrEducation;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class CTASCaseStepDef extends InitiateWebBrowser
{

	CTASLoginScreenObjects CTASLogin;
	CTASWelcomeScreenObjets CTASWelcome;
	CTASAboutYouScreenObjects aboutYou;
	CTASAboutHealthScreenObjects aboutHealth;
	CTASIsolationInformationScreenObjects isolationinformation;
	CTASVulnerableMarkersScreenObjects selfIsolate;
	CTASContactFeedbackScreenObjects feedback;
	CTASIsolationInformationScreenObjects isolationInfo;
	CTASWhereYouLiveScreenObjects youLive;
	CTASMoreAboutWhereYouLiveObjects moreAboutYouLive;
	CTASWhoYouLiveWithScreen liveWith;
	CTASNewPersonDetailScreen newPerson;
	CTASWorkOrEducation workOrEdu;
	CTASActivitiesOutSideScreen activitiesOutside;
	CTASWhereCaughtCovid whereCaught;
	CTASStayOverNightScreen stayOverNight;
	CTASDidYouLeaveHomeScreen leaveHome;
	CTASAnyActivitiesYouDid activitiesYouDid;
	CTASThankYouScreen thankyou;
	
	public CTASCaseStepDef() throws IOException
	{
		super();
		// TODO Auto-generated constructor stub
	}

	@Given("User open link and SignIn with Case account ID and Password")
	public void user_open_link_and_sign_in_with_case_account_id_and_password() throws IOException, InterruptedException 
	{
		InitiateWebBrowser.initiateWebBrowser();
		driver.get(prop.getProperty("CTASContactTracingURL"));
		driver.manage().window().maximize();
		CTASLogin = new CTASLoginScreenObjects(driver);	
		CTASLogin.clickOnSignInBtn();
		Thread.sleep(2000);
		CTASLogin.signIn(prop.getProperty("SC1010_TC010CTASCaseAccountID"), prop.getProperty("SC1010_TC010CTASCasePassword"));
	    
	}

	@When("Enter case details under About You")
	public void enter_details_under_about_you() throws IOException
	{
		aboutYou = new CTASAboutYouScreenObjects(driver);
		aboutYou.enterFirstName(prop.getProperty("CTASCaseFirstName"));
		aboutYou.enterLastName(prop.getProperty("CTASCaseLastName"));
		aboutYou.enterDateOfBirth(prop.getProperty("CTASCaseDateOfBirth"), prop.getProperty("CTASCaseMonthOfBirth"), prop.getProperty("CTASCaseYearOfBirth"));
//		aboutYou.selectEthnicity(prop.getProperty(""));
		aboutYou.enterNHSNumber(prop.getProperty("CTASCaseNHSNumber"));
		aboutYou.selectGender(prop.getProperty("CTASCaseGender"));
		aboutYou.enterHouseNumber(prop.getProperty("CTASCaseHouseNo"));
		aboutYou.enterPostCode(prop.getProperty("CTASCasePostCode"));
		aboutYou.selectCurrentAddressSameAsHomeAddress();
		aboutYou.entercontinueFromAboutUs();

	}
	
	@When("Enter case details under About You for SC1001_TC012")
	public void enter_case_details_under_about_you_for_sc1001_tc012() throws IOException
	{
		aboutYou = new CTASAboutYouScreenObjects(driver);
		aboutYou.enterFirstName(prop.getProperty("SC1001_TC012CTASCaseFirstName"));
		aboutYou.enterLastName(prop.getProperty("SC1001_TC012CTASCaseLastName"));
		aboutYou.enterDateOfBirth(prop.getProperty("SC1001_TC012CTASCaseDateOfBirth"), prop.getProperty("SC1001_TC012CTASCaseMonthOfBirth"), prop.getProperty("SC1001_TC012CTASCaseYearOfBirth"));
//		aboutYou.selectEthnicity(prop.getProperty(""));
		aboutYou.enterNHSNumber(prop.getProperty("SC1001_TC012CTASCaseNHSNumber"));
		aboutYou.selectGender(prop.getProperty("SC1001_TC012CTASCaseGender"));
		aboutYou.enterHouseNumber(prop.getProperty("SC1001_TC012CTASCaseHouseNo"));
		aboutYou.enterPostCode(prop.getProperty("SC1001_TC012CTASCasePostCode"));
// one more field need to be handle i.e. Is this postcode for a care home = No		
		aboutYou.selectCurrentAddressSameAsHomeAddress();
		aboutYou.entercontinueFromAboutUs();

	}
	
	@When("User selects high temprature and provides symptom date under tell us about your health")
	public void user_selects_high_temprature_and_provides_symptom_date_under_tell_us_about_your_health() throws IOException, InterruptedException
	{
		Thread.sleep(1000);
		aboutHealth= new CTASAboutHealthScreenObjects(driver);
		aboutHealth.selectHighTemp();
		LocalDate date = LocalDate.now().minusDays(2);
		String date1= Integer.toString(date.getDayOfMonth());
		String month = Integer.toString(date.getMonthValue());
		String year= Integer.toString(date.getYear());
		aboutHealth.enterSymptomStartdate(date1,month,year);
		CTASWelcome= new CTASWelcomeScreenObjets(driver);
		CTASWelcome.clickOnContinueFromWelcome();
	    
	}
	@When("User enter emailid and phone number on the screen You are required to stay at home")
	public void user_enter_emailid_and_phone_number_on_the_screen_you_are_required_to_stay_at_home() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		isolationInfo = new CTASIsolationInformationScreenObjects(driver);
		isolationInfo.enterEmailAddress(prop.getProperty("CTASCaseEmail"));
		isolationInfo.enterMobileNumber(prop.getProperty("CTASCaseMobile"));
	//	CTASWelcome= new CTASWelcomeScreenObjets(driver);
		CTASWelcome.clickOnContinueFromWelcome();
	    
	}
	@When("User select Your own home or family home on the screen Tell us about where you live")
	public void user_select_your_own_home_or_family_home_on_the_screen_tell_us_about_where_you_live() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		youLive = new CTASWhereYouLiveScreenObjects(driver);
		youLive.whereYouLive(prop.getProperty("CTASCaseWhereYouLive"));
		CTASWelcome= new CTASWelcomeScreenObjets(driver);
		CTASWelcome.clickOnContinueFromWelcome();
	}
	@When("user enter details on Tell us more about where you live screen")
	public void user_enter_details_on_tell_us_more_about_where_you_live_screen() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		moreAboutYouLive = new CTASMoreAboutWhereYouLiveObjects(driver);
		moreAboutYouLive.selectOptioDdescribePlaceWhereYouLiveIn(prop.getProperty("CTASCaseMoreWhereYouLive"));
		moreAboutYouLive.enterNameNumberOfHouse(prop.getProperty("CTASCaseHouseNumber"));
		moreAboutYouLive.enterTownCity(prop.getProperty("CTASCaseCity"));
		moreAboutYouLive.enterCasePostCode(prop.getProperty("CTASCasePostCode"));
		moreAboutYouLive.continueMoreAboutLiving();
	    
	}
	@When("User click on Add Visitor to household on the screen Tell us who you live with")
	public void user_click_on_add_visitor_to_household_on_the_screen_tell_us_who_you_live_with() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		liveWith= new CTASWhoYouLiveWithScreen(driver);
		liveWith.addVisitorToHousehold();
	    
	}
	@When("User enter details of new person")
	public void user_enter_details_of_new_person() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		newPerson= new CTASNewPersonDetailScreen(driver);
		newPerson.enterNewPersonFirstName(prop.getProperty("CTASNewPersonFirstName"));
		newPerson.enternewPersonLastName(prop.getProperty("CTASNewPersonLasttName"));
		newPerson.enterEmailAddress(prop.getProperty("CTASNewPersonEmail"));
		newPerson.enterNewPersonPhoneNumber(prop.getProperty("CTASNewPersonPhone"));
		newPerson.Under18(prop.getProperty("NoUnder18"));
		newPerson.enterCountry(prop.getProperty("CTASNewPersonCountry"));
		newPerson.describeExposure(prop.getProperty("CTASNewPersonExposureType"));
		LocalDate date = LocalDate.now().minusDays(1);
		String date1= Integer.toString(date.getDayOfMonth());
		String month = Integer.toString(date.getMonthValue());
		String year= Integer.toString(date.getYear());
		newPerson.enterDateOfContact(date1, month, year);
		//CTASWelcome= new CTASWelcomeScreenObjets(driver);
		CTASWelcome.clickOnContinueFromWelcome();
	    
	}
	@When("User clicks on No to direct contact with anyone else")
	public void user_clicks_on_no_to_direct_contact_with_anyone_else() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
	 	liveWith= new CTASWhoYouLiveWithScreen(driver);
		liveWith.directContactWithAnyoneElse(prop.getProperty("CTASDirectContact"));
		//CTASWelcome= new CTASWelcomeScreenObjets(driver);
		CTASWelcome.clickOnContinueFromWelcome();
	}
	@When("User clicks on I do not work and I am not educated")
	public void user_clicks_on_i_do_not_work_and_i_am_not_educated() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		workOrEdu= new CTASWorkOrEducation(driver);
		workOrEdu.clickNotInWorkAndnotEducated();
	    
	}
	@When("User clicks on I have not done any activities")
	public void user_clicks_on_i_have_not_done_any_activities() throws IOException, InterruptedException
	{
		Thread.sleep(1000);
		activitiesOutside = new CTASActivitiesOutSideScreen(driver);
		activitiesOutside.clickOnnotDoneSAnyActivities();
	    
	}
	@When("User clicks on Continue on screen Where might you have caught Covid")
	public void user_clicks_on_continue_on_screen_where_might_you_have_caught_covid() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		whereCaught= new CTASWhereCaughtCovid(driver);
		whereCaught.clickOnContinue();
		System.out.println("continue clicked");
	    
	}
	@When("User selects No to Did you stay overnight")
	public void user_selects_no_to_did_you_stay_overnight() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		stayOverNight= new CTASStayOverNightScreen(driver);
		stayOverNight.didYouStayOverNight(prop.getProperty("notStayed"));
		whereCaught= new CTASWhereCaughtCovid(driver);
		//CTASWelcome= new CTASWelcomeScreenObjets(driver);
		CTASWelcome.clickOnContinueFromWelcome();
	    
	}
	@When("User selects No to Did you leave your home")
	public void user_selects_no_to_did_you_leave_your_home() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		leaveHome = new CTASDidYouLeaveHomeScreen(driver);
		leaveHome.didYouleftHome(prop.getProperty("notLeft"));
	//	CTASWelcome= new CTASWelcomeScreenObjets(driver);
		CTASWelcome.clickOnContinueFromWelcome();
	    
	}
	@When("User selects I have not done any of these activities")
	public void user_selects_i_have_not_done_any_of_these_activities() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		activitiesYouDid= new CTASAnyActivitiesYouDid(driver);
		activitiesYouDid.clickNotDoneAnyactivities();
	    
	}
	@Then("User clicks on I would rather not provide feed back")
	public void user_clicks_on_i_would_rather_not_provide_feed_back() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		feedback= new CTASContactFeedbackScreenObjects(driver);
		feedback.clickOnIWouldNotProvideFeedback();
		
	    
	}
	@Then("User gets a screen CaseName thank you very much for completeing this questionainnaire")
	public void user_gets_a_screen_case_name_thank_you_very_much_for_completeing_this_questionainnaire() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		thankyou = new CTASThankYouScreen(driver);
		String toVerify=thankyou.getThankYouMessage();
		String actual="thank you very much for completing this questionnaire";
		Assert.assertTrue(toVerify.contains(actual));
	    
	}
	@Then("User clicks on signout")
	public void user_clicks_on_signout() throws IOException, InterruptedException
	{
		CTASLogin=new CTASLoginScreenObjects(driver);
		CTASLogin.signOut();
	}
	
	@When("Enter case details under About You for SC1010_TC010")
	public void enter_case_details_under_about_you_for_sc1010_tc010() throws IOException, InterruptedException 
	{
		Thread.sleep(1000);
		aboutYou = new CTASAboutYouScreenObjects(driver);
		aboutYou.enterFirstName(prop.getProperty("SC1010_TC010CTASCaseFirstName"));
		aboutYou.enterLastName(prop.getProperty("SC1010_TC010CTASCaseLastName"));
		aboutYou.enterDateOfBirth(prop.getProperty("SC1010_TC010CTASCaseDateOfBirth"), prop.getProperty("SC1010_TC010CTASCaseMonthOfBirth"), prop.getProperty("SC1010_TC010CTASCaseYearOfBirth"));
//		aboutYou.selectEthnicity(prop.getProperty(""));
		aboutYou.enterNHSNumber(prop.getProperty("SC1010_TC010CTASCaseNHSNumber"));
		aboutYou.selectGender(prop.getProperty("SC1010_TC010CTASCaseGender"));
		aboutYou.enterHouseNumber(prop.getProperty("SC1010_TC010CTASCaseHouseNo"));
		aboutYou.enterPostCode(prop.getProperty("SC1010_TC010CTASCasePostCode"));
		aboutYou.selectCurrentAddressSameAsHomeAddress();
		aboutYou.entercontinueFromAboutUs();
	}



	@When("User enter details of new person for SC1010_TC010")
	public void user_enter_details_of_new_person_for_sc1010_tc010() throws IOException, InterruptedException
	{
		Thread.sleep(1000);
		newPerson= new CTASNewPersonDetailScreen(driver);
		newPerson.enterNewPersonFirstName(prop.getProperty("SC1010_TC010CTASNewPersonFirstName"));
		newPerson.enternewPersonLastName(prop.getProperty("SC1010_TC010CTASNewPersonLasttName"));
		newPerson.enterEmailAddress(prop.getProperty("SC1010_TC010CTASNewPersonEmail"));
		newPerson.enterNewPersonPhoneNumber(prop.getProperty("SC1010_TC010CTASNewPersonPhone"));
		newPerson.Under18(prop.getProperty("SC1010_TC010YesUnder18"));
		newPerson.enterCountry(prop.getProperty("SC1010_TC010CTASNewPersonCountry"));
		newPerson.describeExposure(prop.getProperty("SC1010_TC010CTASNewPersonExposureType"));
		LocalDate date = LocalDate.now().minusDays(1);
		String date1= Integer.toString(date.getDayOfMonth());
		String month = Integer.toString(date.getMonthValue());
		String year= Integer.toString(date.getYear());
		newPerson.enterDateOfContact(date1, month, year);
		//CTASWelcome= new CTASWelcomeScreenObjets(driver);
		CTASWelcome.clickOnContinueFromWelcome();
	}

}
