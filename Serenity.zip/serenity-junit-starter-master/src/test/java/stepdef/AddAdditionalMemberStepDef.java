package stepdef;

import java.io.IOException;
import java.time.LocalDate;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.BookFreeTestScreenObjects_old;
import io.cucumber.java.en.Then;

public class AddAdditionalMemberStepDef extends InitiateWebBrowser{
	
	public AddAdditionalMemberStepDef() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
	BookFreeTestScreenObjects_old booktest = new BookFreeTestScreenObjects_old(driver);
	
@Then("User has to provide the name details of the additional person")
public void user_has_to_provide_the_name_details_of_the_additional_person() throws InterruptedException {

	booktest.firstNamelastNameScreen(prop.getProperty("firstnameofadditionalmember"),prop.getProperty("lastnameofadditionalmember"));
     
}

@Then("User enters date of birth of the additional person")
public void user_enters_date_of_birth_of_the_additional_person() {
	String date= prop.getProperty("dateofbirthadditionalmember");
	String month= prop.getProperty("monthofbirthadditionalmember");
	String year= prop.getProperty("yearofbirthadditionalmember");
	booktest.enterDOB(date,month,year);
}
@Then("User has to provide the rough symptoms start date of the additional person")
public void user_has_to_provide_the_rough_symptoms_start_date_of_the_additional_person() throws InterruptedException {
	LocalDate date = LocalDate.now().minusDays(2);
	String date1= Integer.toString(date.getDayOfMonth());
	String month = Integer.toString(date.getMonthValue());
	String year= Integer.toString(date.getYear());
	String startdate = date1;
	String startmonth = month;
	String startyear = year;
	booktest.enterSymptomsStartDate(startdate,startmonth,startyear);
}
@Then("User select yes to having atleast one corona symptom")
public void user_select_yes_to_having_atleast_one_corona_symptom() throws InterruptedException, IOException 
{
	booktest = new BookFreeTestScreenObjects_old(driver);
	booktest.ClickHavingCoronaSymptom();
}
@Then("User has to provide the mobile number of the additional person")
public void user_has_to_provide_the_mobile_number_of_the_additional_person() throws InterruptedException {
	booktest.enterMobileNumber(prop.getProperty("mobileNumberadditionalmember"));
	booktest.ConfirmMobileNumber(prop.getProperty("mobileNumberadditionalmember"));
}
@Then("User select No to landline phone number of the additional person")
public void user_select_no_to_landline_phone_number_of_the_additional_person() throws InterruptedException {
	booktest.landlineNotAvailabile();
}
@Then("User has to provide an email address of the additional person")
public void user_has_to_provide_an_email_address_of_the_additional_person() throws InterruptedException {
	booktest.selectEmailoption();
	booktest.enterEmailAddress(prop.getProperty("emailAddressadditionalmember"));
}
@Then("User has to provide a Gender detail of the additional person")
public void user_has_to_provide_a_gender_detail_of_the_additional_person() {
	booktest.selectGender(prop.getProperty("genderadditionalmember"));
}
@Then("User has to provide a Ethnic group of the additional person")
public void user_has_to_provide_a_ethnic_group_of_the_additional_person() {
	booktest.enterEthnicityGroup(prop.getProperty("EthnicgroupAsian"));
}
@Then("User has to provide Ethnic background of the additional person")
public void user_has_to_provide_Ethnic_background_of_the_additional_person() throws InterruptedException {
	booktest.background(prop.getProperty("EthnicBackgroundIndian"));
}
@Then("User selects currently not in work field of the additional person")
public void user_selects_currently_not_in_work_field_of_the_additional_person() {
	booktest.currentWorkStatusNo();
}
@Then("User has to provide a country of residence of the additional person")
public void user_has_to_provide_a_country_of_residence_of_the_additional_person() {
	booktest.countryOfResidence(prop.getProperty("Country"));  
}
@Then("User has to provide the postcode of the additional person")
public void user_has_to_provide_the_postcode_of_the_additional_person() {
 booktest.enterPostcode(prop.getProperty("postcode"));
	//	booktest.clickPostCodeSame();	
//	System.out.println("Post Code entered");
}
@Then("User selects No to knowing NHS number of the additional person")
public void user_selects_no_to_knowing_nhs_number_of_the_additional_person() {
	booktest.nhsnumberAvailability(prop.getProperty("DontKnowNHS"));
}




}
