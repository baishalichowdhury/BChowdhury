package stepdef;

import java.io.IOException;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.BookFreeTestScreenObjects_old;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class BookHomeTestKit extends InitiateWebBrowser
{

	public BookHomeTestKit() throws IOException 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	
BookFreeTestScreenObjects_old booktest;
@Then("User clicks on Register someone else button")
public void user_clicks_on_register_someone_else_button() throws IOException
 {
	booktest= new BookFreeTestScreenObjects_old(driver);
  booktest.ClickonConfirmandcontinue();
}


@Then("User selects At home to where taking test")
public void user_selects_at_home_to_where_taking_test() throws InterruptedException, IOException 
{
	booktest= new BookFreeTestScreenObjects_old(driver);
   booktest.whereToTakeTest1(prop.getProperty("atHome"));
}
@Then("User enter other person unique test kit barcode number")
public void user_enter_other_person_unique_test_kit_barcode_number() 
{
	booktest.EnterBarCode(prop.getProperty("otherbarcode"));
	booktest.confirmBarCode(prop.getProperty("otherbarcode"));
    
}
@Then("User selects date and time of taking coronavirus test for the other person")
public void user_selects_date_and_time_of_taking_coronavirus_test_for_the_other_person() throws InterruptedException {
	
	   booktest.selectTimeTotaketest();
	   booktest.timeOfTakingTest(prop.getProperty("timeofother"));
	   booktest.clickampm(prop.getProperty("pm"));
    
}
@Then("User enters date of birth of the other person")
public void user_enters_date_of_birth_of_the_other_person() {
    
	String date= prop.getProperty("dateofbirthother");
	String month= prop.getProperty("monthofbirthother");
	String year= prop.getProperty("yearofbirthother");
	booktest.enterDOB(date,month,year);
}
@Then("User has to provide the name details of the other person")
public void user_has_to_provide_the_name_details_of_the_other_person() throws InterruptedException {
    
	String firstname=prop.getProperty("firstNameother");
	String lastName=prop.getProperty("lastNameother");
	booktest.firstNamelastNameScreen(firstname,lastName);	
}
@Then("User has to provide a Gender detail of the other person")
public void user_has_to_provide_a_gender_detail_of_the_other_person() {
    
	booktest.selectGender(prop.getProperty("genderother"));
}
@Then("User has to provide a country of residence of the other person")
public void user_has_to_provide_a_country_of_residence_of_the_other_person() {
    
    booktest.countryOfResidence(prop.getProperty("countryother"));
}
@Then("User has to provide the postcode of the other person")
public void user_has_to_provide_the_postcode_of_the_other_person() {
    
    booktest.enterPostcode(prop.getProperty("postcodeother"));
}
@Then("User has to provide an email address of the other person")
public void user_has_to_provide_an_email_address_of_the_other_person() throws InterruptedException {
    booktest.selectEmailoption(prop.getProperty("emailavailable"));
    booktest.enterEmailAddress(prop.getProperty("emailother"));
}
@Then("User has to provide the mobile number of the other person and confirm it")
public void user_has_to_provide_the_mobile_number_of_the_other_person_and_confirm_it() throws InterruptedException {
    booktest.enterMobileNumber(prop.getProperty("mobileother"));
    booktest.ConfirmMobileNumber(prop.getProperty("mobileother"));
}



@Then("User selects Yes travelling to work for the last two weeks to currently in work field")
public void user_selects_yes_to_currently_in_work_field() throws IOException {
    booktest= new BookFreeTestScreenObjects_old(driver);
    booktest.currentWorkStatus(prop.getProperty("currentworkstatus"));

}


@Then("User selects area of work as Retail")
public void user_selects_area_of_work_as_retail() {
    booktest.areaOfWork(prop.getProperty("workarea"));

}
@Then("User selects Food, meat, drink and tobacco process operative in occupation")
public void user_selects_food_meat_drink_and_tobacco_process_operative_in_occupation() {
    booktest.enterOccupation(prop.getProperty("occupation"));

}
@Then("User need to enter the employer name of the person needing a test")
public void user_need_to_enter_the_employer_name_of_the_person_needing_a_test() {
    booktest.enterEmployer(prop.getProperty("employerName"));

}
@Then("User selects Black, African, Black British or Caribbean in Ethnic group of the next person")
public void user_selects_black_african_black_british_or_caribbean_in_ethnic_group_of_the_next_person() {
    
 booktest.enterEthnicityGroup(prop.getProperty("EthnicgroupAfrican"));
}
@Then("User select African in background")
public void user_select_african_in_background() {
    booktest.background(prop.getProperty("backgroundAfrican"));

}
@Then("User selects Yes to knowing NHS number of the next person")
public void user_selects_yes_to_knowing_nhs_number_of_the_next_person() {
    
booktest.nhsnumberAvailability(prop.getProperty("NHSYes"));
}
@Then("User enter NHS number of the next person")
public void user_enter_nhs_number_of_the_next_person() {
    
booktest.enternhsnumber(prop.getProperty("nhsNumberOther"));
}

@When("User enter orderid on the page of What's your orderid")
public void user_enter_orderid_on_the_page_of_what_s_your_orderid() throws IOException
 {
	booktest= new BookFreeTestScreenObjects_old(driver);
    booktest.enterOrderId(prop.getProperty("ordeId"));
}

@When("User selects Today date and five pm time of taking coronavirus test")
public void user_selects_today_date_and_five_pm_time_of_taking_coronavirus_test() throws IOException, InterruptedException 
{
	
	booktest= new BookFreeTestScreenObjects_old(driver);
	booktest.selectTimeTotaketest();
	booktest.timeOfTakingTest(prop.getProperty("timeOfTakingTest"));
	booktest.clickampm(prop.getProperty("pm"));
	
}
}
