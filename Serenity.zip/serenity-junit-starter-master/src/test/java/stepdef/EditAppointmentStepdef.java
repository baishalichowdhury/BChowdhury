package stepdef;

import java.io.IOException;

import org.junit.Assert;

import DempProject.base.InitiateWebBrowser;
import gov.dhsc.qat.nhstt.pageobjects.BookFreeTestScreenObjects_old;
import io.cucumber.java.en.Then;

public class EditAppointmentStepdef extends InitiateWebBrowser
{

	public EditAppointmentStepdef() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
BookFreeTestScreenObjects_old booktest;	



@Then("User selects Asian or Asian British in Ethnic group of the next person")
public void user_selects_asian_or_asian_british_in_ethnic_group_of_the_next_person() throws IOException {
	booktest= new BookFreeTestScreenObjects_old(driver);
booktest.enterEthnicityGroup(prop.getProperty("EthnicgroupAsian"));

}
@Then("User select Indian in background")
public void user_select_indian_in_background() {

	booktest.background(prop.getProperty("background"));
}
@Then("User selects No to currently in work field")
public void user_selects_no_to_currently_in_work_field() {
booktest.currentWorkStatus(prop.getProperty("currentWorkStatusNo"));

}
@Then("User selects test site")
public void user_selects_test_site() throws InterruptedException {

	booktest.enterPostcodeTestsite(prop.getProperty("postcode"));
	booktest.chooseTestSite(prop.getProperty("testsite"));
}
@Then("user choose time of taking test")
public void user_choose_time_of_taking_test() throws InterruptedException {
	//booktest.clickNextday();
	
	booktest.selectTimeSlot(prop.getProperty("TimeSlotFirst"));

}

@Then("user will get no slots available")
public void user_will_get_no_slots_available() {
   /* String actualMessage=booktest.getTextNoSlot();
    String toVerify="There are currently no slots available on this day";
    Assert.assertTrue(actualMessage.contains(toVerify));*/
}

@Then("User click on change site")
public void user_click_on_change_site() {

booktest.clickChangeTestSite();
}
@Then("User selects other test site")
public void user_selects_other_test_site() throws InterruptedException {
	booktest.chooseTestSite(prop.getProperty("testSiteSecond"));
}

@Then("user clicks on Save and Continue under appointment detail page")
public void user_clicks_on_save_and_continue_under_appointment_detail_page() {


}
@Then("User should get appointment booked confirmation")
public void user_should_get_appointment_booked_confirmation() {


}




}
