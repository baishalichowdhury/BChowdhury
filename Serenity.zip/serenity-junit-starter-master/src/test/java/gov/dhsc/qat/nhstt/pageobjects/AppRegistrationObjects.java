package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AppRegistrationObjects extends HomeScreenObjects
{

	public AppRegistrationObjects(WebDriver driver) throws IOException 
	{
		super(driver);
	}
	
	@FindBy(id="uk.nhs.covid19.internal:id/confirmOnboarding")
	WebElement continuebtn;
	
	@FindBy(id="android:id/button1")
	WebElement AboveSixteen;
	
	@FindBy(id="android:id/button2")
	WebElement BelowSixteen;
	
	@FindBy(id="uk.nhs.covid19.internal:id/buttonAgree")
	WebElement IAgree;
	
	@FindBy(id="uk.nhs.covid19.internal:id/textNoThanks")
	WebElement NoThanks;
	
	@FindBy(id="uk.nhs.covid19.internal:id/postCodeEditText")
	WebElement PostCode;
	
	@FindBy(id="uk.nhs.covid19.internal:id/postCodeContinue")
	WebElement ContinuefromPostCode;
	
	@FindBy(id="uk.nhs.covid19.internal:id/permissionContinue")
	WebElement ContactTracingContinue;
	
	@FindBy(id="android:id/button1")
	WebElement TurnOn;
	
	@FindBy(id="uk.nhs.covid19.internal:id/edgeCaseTitle")
	WebElement Below16ScreenMessage;
	
	@FindBy(id="uk.nhs.covid19.internal:id/welcomeTitle")
	WebElement NoThanksMessage;
	
	@FindBy(id="uk.nhs.covid19.internal:id/welcomeTitle")
	WebElement WelcomeMessage;
	
	public void clickOnContinue()
	{
		continuebtn.click();
	}
	
	public void selectAbovesixteen() throws InterruptedException
	{

		Thread.sleep(1000);
		AboveSixteen.click();
	}
	
	public void selectBelowSixteen() throws InterruptedException
	{

		Thread.sleep(1000);
		BelowSixteen.click();
	} 
	
	public String getMessageBelow16()
	{
		return(Below16ScreenMessage.getText());
	}
	
	public void clickOnIAgree()
	{
		
		IAgree.click();
	}
	
	public void clickOnNoThanks()
	{
		NoThanks.click();
		
	}
	
	public String NoThanksMessage()
	{
		return(NoThanksMessage.getText());
		
	}
	
	
	public void enterPostCode(String postcode)
	{
		PostCode.sendKeys(postcode);
	}
	
	public void PostCodeContinue()
	{
		ContinuefromPostCode.click();
	}
	
	public void ContinueContactTrace()
	{
		
		ContactTracingContinue.click();
	}
	
	public void selectTurnOn() throws InterruptedException
	{
		TurnOn.click();
	}
	
    public String getWelcomeMessage()
    {
       return(WelcomeMessage.getText())	;
    }

}
