package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class CountryOfResidenceScreenObjects extends MainScreenObjects
{
	
	public CountryOfResidenceScreenObjects(AppiumDriver<MobileElement> driver) throws IOException {
		super(driver);
	}

	@FindBy(xpath="//*[@id=\"country\"]")
	WebElement countryengland;
	
	@FindBy(id="country-4")
	WebElement countrywales;
	
	@FindBy(css="button[class*='govuk-button']")
	WebElement Continue;
	
		public void countryOfResidenceEngland()
	{
		countryengland.click();
		Continue.click();
	}
	
	public void countryOfResidenceWales()
	{
		countrywales.click();
		Continue.click();
	}
	

}
