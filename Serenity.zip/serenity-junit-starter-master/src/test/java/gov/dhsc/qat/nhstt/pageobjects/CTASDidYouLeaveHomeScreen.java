package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASDidYouLeaveHomeScreen extends HomeScreenObjects 
{

	public CTASDidYouLeaveHomeScreen(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(css="#backwards-tracing-state-attended-work-or-education-true-field")
	WebElement yesLeft;
	
	@FindBy(css="#backwards-tracing-state-attended-work-or-education-field")
	WebElement notLeft;
	
	public void didYouleftHome(String option) throws InterruptedException
	{
		Thread.sleep(2000);
		if(option.equalsIgnoreCase("Yes"))
		{
			yesLeft.click();
		}
		else if(option.equalsIgnoreCase("No"))
		{
			notLeft.click();
		}
	}

}
