package gov.dhsc.qat.nhstt.pageobjects;

import static io.appium.java_client.touch.offset.PointOption.point;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;

import javax.imageio.ImageIO;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class MainScreenObjects extends HomeScreenObjects
{

	public MainScreenObjects(WebDriver driver) throws IOException
	{
		super(driver);
	}

	@FindBy (id="uk.nhs.covid19.internal:id/optionReportSymptoms")
	static WebElement checkSymptomsbtn;
	
	
	@FindBy (id="uk.nhs.covid19.internal:id/riskyPostCode")
	static WebElement riskyPostcodebtn;
	
	@FindBy (xpath="//android.widget.LinearLayout[contains(@resource-id,'uk.nhs.covid19.internal:id/riskAreaView')]/android.widget.TextView[contains(@resource-id,'uk.nhs.covid19.internal:id/statusOptionText')]")
	static WebElement riskLevelStatus;
	
	@FindBy (xpath="//android.widget.LinearLayout[@content-desc=\"Book a free test, Button\"]")
	static WebElement bookFreeTest; 
	
	@FindBy (xpath="//android.widget.LinearLayout[contains(@resource-id,'uk.nhs.covid19.internal:id/riskAreaView')]/android.widget.FrameLayout/android.widget.ImageView")
	static WebElement mapIcon; 
	
	@FindBy (id="uk.nhs.covid19.internal:id/titleIsolationCountdown")
	WebElement titleIsolationCountdown;
	
	@FindBy (id="uk.nhs.covid19.internal:id/subTitleIsolationCountdown")
	WebElement subTitleIsolationCountdown;
	
	@FindBy (id="uk.nhs.covid19.internal:id/imgCirclePulseAnim")
	WebElement days;
	
	@FindBy (id="uk.nhs.covid19.internal:id/titleDaysToGo")
	WebElement titleDaysToGo;
	
	@FindBy (id="uk.nhs.covid19.internal:id/optionAboutTheApp")
	WebElement AboutThisAppBtn;
	
	@FindBy(xpath="//android.widget.Button[(@text='Continue')]")
	WebElement Continue;
	
	
	public void clickOnAboutThisAppBtn() 
	{	
		AboutThisAppBtn.click();
	}
	
	public String selfIsolationMessage()
	 {
		 String message= titleIsolationCountdown.getText()+" "+subTitleIsolationCountdown.getText()+" "+days.getText()+" "+titleDaysToGo.getText();
		 return message;
	 }
		
	
	public static void clickOncheckSymptomsbtn() 
	{	
		checkSymptomsbtn.click();
	}
	
	public static void clickRiskyPostcodebtn() 
	{	
		 riskyPostcodebtn.click();
		 
	}
	
	public static void clickOnriskLevelStatus() 
	{	
		riskLevelStatus.click();
	}
	
	public String getRiskLevel() throws InterruptedException
	{
       Thread.sleep(2000);
       System.out.println(riskLevelStatus.getText());
	   return(riskLevelStatus.getText());	
	}
	
	public static void clickOnBookFreeTest()
	{
		bookFreeTest.click();
	} 
	
	public String getColorOfRiskLevelStatus() throws IOException
	{
		String color="inspect";
		Dimension d = mapIcon.getSize();
	    int centerx = d.width/2;
		int centerY = d.height/2;
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    FileHandler.copy(scrFile, new File("C:/Users/KAgrawal_adm/Downloads/nhsttt1Final/src/test/resources/nhsttt.config/screenshots/location.png"));	
		 BufferedImage image = ImageIO.read(scrFile);
		  int clr=  image.getRGB(centerx,centerY); 
		  System.out.println("vale of clr "+clr);
		  int  red   = (clr & 0x00ff0000) >> 16;
		  int  green = (clr & 0x0000ff00) >> 8;
		  int blue = clr & 0xff;
		  System.out.println(red);
		  System.out.println(green);
		  System.out.println(blue);
		  if(clr==-16752968)
		  {
			  color ="Green";
		  }
		  else
		  {
			  color ="red or amber";
		  }
		 
	/*	  final Color RGB_COLOUR = Color.fromString("rgb(red, green, blue)");
		  System.out.println(RGB_COLOUR);
		  color = RGB_COLOUR.toString() ;
		  System.out.println(color);*/
		return color;
		
	} 
		 
 
	
	@SuppressWarnings("rawtypes")
	public static void swipeToBottom() throws InterruptedException
	{
		/*
		 * Dimension dim= driver.manage().window().getSize(); int height =
		 * dim.getHeight(); int width = dim.getWidth(); int x = (int) (width*0.98);
		 * System.out.println("value of x is : "+x); int bottom_y= (int)(height*0.80);
		 * int top_y= (int)(height*20);
		 * 
		 * Thread.sleep(1000); TouchAction ts = new TouchAction(driver);
		 * ts.press(point(x, bottom_y)).moveTo(point(x, top_y)).release().perform();
		 
		  Thread.sleep(1000);
		  TouchAction ts = new TouchAction(driver);
		  ts.press(point(1078, 1660)).moveTo(point(1078, 340)).release().perform();
		  Thread.sleep(1000);*/
			
	}
	@SuppressWarnings("rawtypes")
	public static void swipeToBottom1() throws InterruptedException
	{
		/*  Thread.sleep(1000);
		  TouchAction ts = new TouchAction(driver);
		  ts.press(point(1078, 1680)).moveTo(point(1078, 340)).release().perform();
		  Thread.sleep(1000);*/
			
	}
   public void switchWindowTab()
   {
	   ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs.get(1));
	    
   }
	public void switchContext() throws InterruptedException
	{
		/*Thread.sleep(1000);
		Set<String> contextNames = driver.getWindowHandles();
		for (String context : contextNames ) 
		{
			if(!context.contains("NATIVE_APP"))
			{
				driver.context(context);
				break;
			}
		}
		Thread.sleep(200);*/
	}
	
	public String getFutureDaysDate(int day)
	{
		 final String DATE_FORMAT = "dd MMM yyyy HH:mm:ss";
		    final DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		    final DateTimeFormatter dateFormat8 = DateTimeFormatter.ofPattern(DATE_FORMAT);
			// Get current date
		        Date currentDate = new Date();
		        System.out.println("date : " + dateFormat.format(currentDate));
		        // convert date to localdatetime
		        LocalDateTime localDateTime = currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
		        System.out.println("localDateTime : " + dateFormat8.format(localDateTime));
		        // plus seven
		        localDateTime = localDateTime.plusYears(0).plusMonths(0).plusDays(day);
		     // localDateTime = localDateTime.plusHours(1).plusMinutes(2).minusMinutes(1).plusSeconds(1);
		        // convert LocalDateTime to date
		        Date currentDatePlusEightDays = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
		        System.out.println("\nOutput : " + dateFormat.format(currentDatePlusEightDays));
		        String futuredate= dateFormat.format(currentDatePlusEightDays).substring(0, 11);
		        return(futuredate);
	}
	
	public void clickOnContinue() throws InterruptedException
	{
		swipeToBottom();
		Continue.click();
	}
}
