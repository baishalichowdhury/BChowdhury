package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASWelcomeScreenObjets extends HomeScreenObjects
{

	public CTASWelcomeScreenObjets(WebDriver driver) throws IOException 
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(css="#episode-proxy-present-true-field")
	WebElement someOneelse;
	
	@FindBy(css="#episode-proxy-present-false-field")
	WebElement Myself;
	
	@FindBy(css="#episode-proxy-forename-field")
	WebElement proxyFirstName;
	
	@FindBy(css="#episode-proxy-surname-field")
	WebElement proxyLastName;
	
	@FindBy(css="#episode-proxy-house-number-field")
	WebElement proxyHouseNumber;
	
	@FindBy(css="#episode-proxy-postcode-field")
	WebElement proxyPostCode;
	
	@FindBy(css="#main-content > div > div > form > input.nhsuk-button.nhsuk-button--primary")
	WebElement continueFromWelcome;
	
	@FindBy(css="#main-content > div > div > a")
	WebElement continueWhereMightCaught;
	
	public void clickcontinueWhereMightCaught()
	{
		continueWhereMightCaught.click();
	}
	
	public void selectSomeoneElse()
	{
		someOneelse.click();
	}
	
	public void selectMyself()
	{
		Myself.click();
	}
	
	public void enterProxyFirstName(String name)
	{
		proxyFirstName.sendKeys(name);
	}
	
	public void enterProxyLastName(String lastname)
	{
		proxyLastName.sendKeys(lastname);
	}
	
	public void enterProxyHouseNo(String houseNumber)
	{
		proxyHouseNumber.sendKeys(houseNumber);
	}
	
	public void enterProxyPostCode(String postcode)
	{
		proxyPostCode.sendKeys(postcode);
	}
	
	public void clickOnContinueFromWelcome()
	{
		continueFromWelcome.click();
	}
}
