package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import DempProject.base.InitiateWebBrowser;

public class HomeScreenObjects extends InitiateWebBrowser

{
	
	@FindBy (id="uk.nhs.covid19.internal:id/scenario_main")
	WebElement mainScreenbtn;
	
	
	
	public void clickOnMainScreenBtn() 
	{	
		if(mainScreenbtn.isDisplayed())
		{
		mainScreenbtn.click();
		}
	}
	
	public void getAPK()
	{
	   System.out.println("getting app");
	}
	
	public void install() throws IOException
	 {
	   System.out.println("installed");
	 }
	
	public void waitMethod() throws InterruptedException
	{
	  Thread.sleep(1000);
	}
	public HomeScreenObjects(WebDriver driver) throws IOException
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(css="button[class*='govuk-button']")
	WebElement Continue;
	
public void clickOnContinue() throws InterruptedException
{
	Continue.click();
}
@SuppressWarnings("rawtypes")
public void swipeDown()
{
//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
}
public static void swipeDownWeb() throws InterruptedException
{		 
	JavascriptExecutor js= (JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,2000)");

}
	 
}
