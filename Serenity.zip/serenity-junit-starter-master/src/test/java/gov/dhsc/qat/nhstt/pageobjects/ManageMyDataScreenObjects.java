package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ManageMyDataScreenObjects extends AboutThisAppScreenObject
{

	public ManageMyDataScreenObjects(WebDriver driver) throws IOException 
	{
		super(driver);
	}
	
	@FindBy(id="uk.nhs.covid19.internal:id/editPostalDistrict")
	WebElement EditPostcode;
	
	@FindBy(id="uk.nhs.covid19.internal:id/postCodeEditText")
	WebElement postCodeEditText;
	
	@FindBy(id="uk.nhs.covid19.internal:id/savePostCode")
	WebElement savePostCode;
	
	public void clickOnEditPostcode()
	{
		EditPostcode.click();
	}
	
	public void EditpostCode(String postcode)
	{
		postCodeEditText.clear();
		postCodeEditText.sendKeys(postcode);
	}
	
	public void clickOnSavePostcode()
	{
		savePostCode.click();
	}

}
