package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASWhereYouLiveScreenObjects extends HomeScreenObjects
{

	public CTASWhereYouLiveScreenObjects(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	// continueFromWelcome will work
	
	@FindBy(css="#event-exposure-group-type-living-alone-or-with-family-field")
	WebElement ownHome;
	
	@FindBy(css="#event-exposure-group-type-shared-field")
	WebElement sharedLivingSpace;
	
	@FindBy(css="#event-exposure-group-type-holiday-field")
	WebElement holidayPlace;
	
	@FindBy(css="#event-exposure-group-type-supported-living-field")
	WebElement supportedLiving;
	
	@FindBy(css="#event-exposure-group-type-other-field")
	WebElement otherPlaces;
	
	public void whereYouLive(String option)
	{
		if(option.equalsIgnoreCase("Own Home"))
		{
			ownHome.click();
		}
		else if (option.equalsIgnoreCase("Shared Living Space"))
		{
			sharedLivingSpace.click();
		}
		
		else if (option.equalsIgnoreCase("Holiday Places"))
		{
			holidayPlace.click();
		}
		
		else if (option.equalsIgnoreCase("Supported living"))
		{
			supportedLiving.click();
		}
		
		else if (option.equalsIgnoreCase("Other Places"))
		{
			otherPlaces.click();
		}
	}


}
