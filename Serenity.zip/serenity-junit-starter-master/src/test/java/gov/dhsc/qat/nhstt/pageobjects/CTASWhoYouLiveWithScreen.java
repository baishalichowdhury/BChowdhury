package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASWhoYouLiveWithScreen extends HomeScreenObjects
{

	public CTASWhoYouLiveWithScreen(WebDriver driver) throws IOException 
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}

	//@FindBy(css="#main-content > div > div > p:nth-child(6) > a")
	@FindBy(xpath="//*[text()[contains(.,'Add member of household')]]")
	WebElement addHouseholdMember;
	
	//@FindBy(css="#main-content > div > div > p:nth-child(13) > a")  
	@FindBy(xpath="//*[text()[contains(.,'Add visitor to household')]]")
	WebElement addVisitorToHousehold;
	
	@FindBy(css="#event-unspecified-direct-contacts-true-field")
	WebElement yesAnyoneElse;
	
	@FindBy(css="#event-unspecified-direct-contacts-field")
	WebElement noAnyoneElse;
	
	//continueFromWelcome will work
	
	public void addHouseholdMember()
	{
		addHouseholdMember.click();
	}
	
	public void addVisitorToHousehold()
	{
		addVisitorToHousehold.click();
	}
	
	public void directContactWithAnyoneElse(String option)
	{
	  if(option.equalsIgnoreCase("yes"))
	  {
		  yesAnyoneElse.click();
	  }
	  else if(option.equalsIgnoreCase("no"))
	  {
		  noAnyoneElse.click();
	  }
	}
	
	
}
