package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASIsolationInformationScreenObjects extends HomeScreenObjects
{

	public CTASIsolationInformationScreenObjects(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	//clickOnContinueFromWelcome will work
	
	@FindBy(css="#main-content > div > div > h1")
	WebElement isolationMessage;
	
	@FindBy(css="#isolation-advice-detail-mobile-phone-field")
	WebElement mobileNumber;
	
	@FindBy(css="#isolation-advice-detail-email-field")
	WebElement emailAddress;
	
	public void enterMobileNumber(String number)
	{
		mobileNumber.clear();
		mobileNumber.sendKeys(number);
	}
	
	public void enterEmailAddress(String email)
	{
		emailAddress.clear();
		emailAddress.sendKeys(email);
	}
	public String getIsolationMessage()
	{
		return(isolationMessage.getText());
	}

}
