package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class CTASAboutYouScreenObjects extends HomeScreenObjects
{

	public CTASAboutYouScreenObjects(WebDriver driver) throws IOException 
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(css="#individual-forename-field")
	WebElement firstName;
	
	@FindBy(css="#individual-surname-field")
	WebElement lastName;
	
	@FindBy(css="#individual_date_of_birth_3i")
	WebElement dateOfBirth;
	
	@FindBy(css="#individual_date_of_birth_2i")
	WebElement monthOfBirth;
	
	@FindBy(css="#individual_date_of_birth_1i")
	WebElement yearOfBirth;
	
	@FindBy(css="#ethnicity")
	WebElement ethnicity;
	
	@FindBy(css="#individual-nhsnumber-field")
	WebElement NHSNumber;
	
	@FindBy(css="#individual-sex-female-field")
	WebElement female;
	
	@FindBy(css="#individual-sex-male-field")
	WebElement male;
	
	@FindBy(css="#individual-house-number-field")
	WebElement houseNumber;
	
	@FindBy(css="#individual-postcode-field")
	WebElement postcode;
	
	@FindBy(css="#main-content > div > div > div > form > input.nhsuk-button.nhsuk-button--primary")
    WebElement continueFromAboutUs;
	
	@FindBy(css="#individual-current-address-same-as-home-address-true-field")
	WebElement currentAddressSameAsHomeAddress;
	
	public void enterFirstName(String name)
   {
		firstName.clear();
	   firstName.sendKeys(name);
   }
   
   public void enterLastName(String lastname)
   {
	   lastName.clear();
	   lastName.sendKeys(lastname);
   }
   
   public void enterDateOfBirth(String day,String month, String Year)
   {
	   dateOfBirth.clear();
	   dateOfBirth.sendKeys(day);
	   monthOfBirth.clear();
	   monthOfBirth.sendKeys(month);
	   yearOfBirth.clear();
	   yearOfBirth.sendKeys(Year);
   }
   
   public void selectEthnicity(String ethnicityName)
   {
	   Select select= new Select(ethnicity);
	   select.selectByValue(ethnicityName);
   }
   
   public void enterNHSNumber(String NHSNumber1)
   {
	   NHSNumber.clear();
	   NHSNumber.sendKeys(NHSNumber1);
   }
   
   public void selectGender(String gender)
   {
	   if(gender.equalsIgnoreCase("female"))
		   female.click();
	   else if(gender.equalsIgnoreCase("male"))
		   male.click();
	   
   }
   
   public void enterHouseNumber(String housenum)
   {
	   houseNumber.clear();
	   houseNumber.sendKeys(housenum);
   }
   
   public void enterPostCode(String Postcode1)
   {
	   postcode.clear();
	   postcode.sendKeys(Postcode1);
   }
   
   public void selectCurrentAddressSameAsHomeAddress()
   {
	   currentAddressSameAsHomeAddress.click();
   }
   
   public void entercontinueFromAboutUs()
   {
	   continueFromAboutUs.click();
   }

}
