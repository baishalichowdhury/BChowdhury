package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASActivitiesOutSideScreen extends HomeScreenObjects
{

	public CTASActivitiesOutSideScreen(WebDriver driver) throws IOException 
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(xpath="//*[text()[contains(.,'I have not done any activities')]]")
	WebElement notDoneSAnyActivities;
	
	@FindBy(xpath="//*[text()[contains(.,'Continue')]]")
	WebElement continueActivitiesOutSide;
	
	public void clickOnnotDoneSAnyActivities()
	{
		notDoneSAnyActivities.click();
	}
	
	

}
