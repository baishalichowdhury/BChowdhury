package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASAnyActivitiesYouDid extends HomeScreenObjects
{

	public CTASAnyActivitiesYouDid(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(css="#main-content > div > div > p > a.nhsuk-button.nhsuk-button--secondary")
	WebElement notDoneAnyActivities;
	
	@FindBy(css="#main-content > div > div > p > a:nth-child(1)")
	WebElement addActivities;
	
	public void clickNotDoneAnyactivities() throws InterruptedException
	{
		Thread.sleep(2000);
		notDoneAnyActivities.click();
	}

}
