package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class EssentialWorkerScreenObjects extends MainScreenObjects
{

	public EssentialWorkerScreenObjects(WebDriver driver) throws IOException
	{
		super(driver);
	}
	

	@FindBy(css="#essential-worker-2")
	WebElement essentialWorkerNo;
	
	@FindBy(css="#essential-worker")
	WebElement essentialworkeryes;
	
	
	@FindBy(css="#essential-worker-3")
	WebElement essentialworkerdontknow;
	
   @FindBy(xpath="//*[@id='main-content']/div/div/form/button")
   WebElement ContinueEssential;
   
	
	public void selectEssentialWorker(String option) throws InterruptedException
	{
		if(option.equalsIgnoreCase("No"))
		{
			Thread.sleep(2000);
			essentialWorkerNo.click();
		}
		else if(option.equalsIgnoreCase("Yes"))
		{
			essentialworkeryes.click();
		}
		else if(option.equalsIgnoreCase("Don't know"))
		{
			essentialworkerdontknow.click();
		}
		
		
		ContinueEssential.click();
	}

}
