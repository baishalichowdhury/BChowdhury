package gov.dhsc.qat.nhstt.pageobjects;

import static io.appium.java_client.touch.offset.PointOption.point;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;


public class EthnicityGroupScreenObjects extends HomeScreenObjects{

	
	
	public EthnicityGroupScreenObjects(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(css="#ethnicity-group")
	WebElement ethnicgroupasian;
	
//	@FindBy(css="#ethnicity-group-4")
	@FindBy(xpath="//*[@id=\"ethnicity-group-4\"]")
	WebElement ethnicgroupwhite;
	
	@FindBy(xpath="//*[@id=\"ethnicity-group-7\"]")
	WebElement ethnicitygroupprefernotsay;
	
	public void selectEthnicityGroup(String ethnicGroupOptionChosen) throws InterruptedException
	{
	if (ethnicGroupOptionChosen.equalsIgnoreCase("Asian")) 
	  { ethnicgroupasian.click(); 
	  } 
	  else if(ethnicGroupOptionChosen.equalsIgnoreCase("White")) 
	  { ethnicgroupwhite.click(); 
	  } 
	  else if(ethnicGroupOptionChosen.equalsIgnoreCase("Prefer not to say")) {
		  ethnicitygroupprefernotsay.click(); 
	  }
		MainScreenObjects_old.swipeToBottom();
	  
	  Thread.sleep(500);
	  }
}
