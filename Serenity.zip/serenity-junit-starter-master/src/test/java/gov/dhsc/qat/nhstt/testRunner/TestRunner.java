package gov.dhsc.qat.nhstt.testRunner;

import org.junit.runner.RunWith;
import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;


@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        plugin = {"pretty","html:target/cucumber.html","json:target/cucumber.json"}, 
        features = {"src/test/resources/features"},
        glue = {"stepdef"},
        dryRun= false,
        tags="@SC1010_TC011"  
)

public class TestRunner
{
	
}
