package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASVulnerableMarkersScreenObjects extends HomeScreenObjects
{

	public CTASVulnerableMarkersScreenObjects(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
// welcomecontinue will work
	
 @FindBy(css="#episode-la-support-not-applicable-true-field")	
 WebElement noneOfThese;

 @FindBy(css="#main-content > div > div > h1")
 WebElement selfIsolateMessage;
 
 public String getSelfIsolateMessage()
 {
	 return(selfIsolateMessage.getText());
 }
 
 public void selectNoneOfThese()
 {
	 noneOfThese.click();
 }
 
 
}
