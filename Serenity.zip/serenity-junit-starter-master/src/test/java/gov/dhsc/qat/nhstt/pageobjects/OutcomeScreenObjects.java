package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class OutcomeScreenObjects extends ReviewSymptomsScreenObjects
{
	public OutcomeScreenObjects(WebDriver driver) throws IOException 
	{
		super(driver);
	}

	@FindBy(id= "uk.nhs.covid19.internal:id/preDaysTextView")
	WebElement preDaysTextView;
	
	@FindBy(id="uk.nhs.covid19.internal:id/daysUntilExpirationTextView")
	WebElement daysToIsolate;
	
	@FindBy(id="uk.nhs.covid19.internal:id/postDaysTextView")
	WebElement postDaysTextView;
	
	@FindBy(xpath="//android.widget.ImageButton[@content-desc='Go back']")
	WebElement CancelBtn;
	
	public String getTextOnResultScreen()
	{
		String message= preDaysTextView.getText()+" "+daysToIsolate.getText()+" "+postDaysTextView.getText();
		System.out.println(message);
		return(message);
	}
	
	
	public void clickOnCancelBtn()
	{
		CancelBtn.click();
	}
}
