package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class OccupationScreenObjects extends HomeScreenObjects
{
	
public OccupationScreenObjects(WebDriver driver) throws IOException
{
		super(driver);
}

@FindBy(id="occupation")
WebElement occupationlistbox;

@FindBy(css="#main-content > div > div > form > div > fieldset > div > ul > li:nth-child(1)")
WebElement occupationlistboxselection;

@FindBy(css="#main-content > div > div > form > button")
WebElement continueBtn;

public void selectOccupationListBox()
{
	occupationlistbox.sendKeys(prop.getProperty("occupation"));
	waitforelement(occupationlistboxselection);
	occupationlistboxselection.click();
	continueBtn.click();
}

public void selectOccupationListCannotFind()
{
	occupationlistbox.sendKeys(prop.getProperty("occupationcannotfind"));
	occupationlistboxselection.click();
	continueBtn.click();
}

public void clickOnContinue() 
{
	// TODO Auto-generated method stub
	
}
public void waitforelement(WebElement element)
{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	wait.until(ExpectedConditions.visibilityOf(element));
}

public void waitforsecuritycheck(WebElement el)
{
	WebDriverWait wait = new WebDriverWait(driver, 240);
	wait.until(ExpectedConditions.visibilityOf(el));
}


}
