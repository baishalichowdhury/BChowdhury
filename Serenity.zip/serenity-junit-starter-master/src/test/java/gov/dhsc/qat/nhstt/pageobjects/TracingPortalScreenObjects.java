package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TracingPortalScreenObjects extends HomeScreenObjects{

	public TracingPortalScreenObjects(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
@FindBy(css="#main-content > div > div > div > div > a")
WebElement signinbutton;

@FindBy(css="#individual-account-id-field")
WebElement accountid;

@FindBy(css="#individual-password-field")
WebElement password;

@FindBy(css="#new_individual > input.nhsuk-button.nhsuk-button--primary")
WebElement credentialsignin;

@FindBy(css="#episode-proxy-present-false-field")
WebElement myself;

@FindBy(css="#main-content > div > div > form > input.nhsuk-button.nhsuk-button--primary")
WebElement Continue;

@FindBy(css="#individual-forename-field")
WebElement firstname;

@FindBy(css="#individual-surname-field")
WebElement lastname;

@FindBy(css="#individual_date_of_birth_3i")
WebElement birthdaydate;

@FindBy(css="#individual_date_of_birth_2i")
WebElement birthmonth;

@FindBy(css="#individual_date_of_birth_1i")
WebElement birthyear;

@FindBy(css="#individual-nhsnumber-field")
WebElement nhsnumber;

@FindBy(css="#individual-sex-male-field")
WebElement gendermale;

@FindBy(css="#individual-house-number-field")
WebElement housenumber;

@FindBy(css="#individual-postcode-field")
WebElement postcode;



public void selectSignIn() throws InterruptedException
{
	swipeDownWeb();
	signinbutton.click();
}

public void enterCredentials(String accid, String pw)
{
	accountid.sendKeys(accid);
	password.sendKeys(pw);
	credentialsignin.click();
}

public void selectMyself()
{
	myself.click();
	Continue.click();
	
}
}
