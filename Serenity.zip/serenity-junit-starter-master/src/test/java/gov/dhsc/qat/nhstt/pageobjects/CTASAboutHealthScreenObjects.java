package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;
import java.time.LocalDate;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASAboutHealthScreenObjects extends HomeScreenObjects
{
	public CTASAboutHealthScreenObjects(WebDriver driver) throws IOException 
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(css="#episode-cough-true-field")
	WebElement newContinousCough;
	
	@FindBy(css="#episode-fever-true-field")
	WebElement highTemprature;
	
	@FindBy(css="#episode-loss-of-smell-or-taste-true-field")
	WebElement lossOrChangeInSenseOfSmell;
	
	@FindBy(css="#episode-had-no-symptoms-true-field")
	WebElement noneOfThese;
	
	@FindBy(css="#episode_first_symptomatic_at_3i")
	WebElement symptomStartDate;
	
	@FindBy(css="#episode_first_symptomatic_at_2i")
	WebElement symptomStartMonth;
	
	@FindBy(css="#episode_first_symptomatic_at_1i")
	WebElement symptomStartYear;
	
	//continueFromWelcome will work for this page
	
	public void selectContinousCough()
	{
		newContinousCough.click();
	}
	
	public void selectHighTemp()
	{
		highTemprature.click();
	}
	
	public void selectNoneOfThese()
	{
		noneOfThese.click();
	}
	
	public void enterSymptomStartdate(String day,String month,String year)
	{
		symptomStartDate.sendKeys(day);
		symptomStartMonth.sendKeys(month);
		symptomStartYear.sendKeys(year);
	}
	
}
