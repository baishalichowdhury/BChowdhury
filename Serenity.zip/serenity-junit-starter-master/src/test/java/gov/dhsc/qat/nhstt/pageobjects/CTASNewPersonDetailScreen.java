package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASNewPersonDetailScreen extends HomeScreenObjects
{

	public CTASNewPersonDetailScreen(WebDriver driver) throws IOException 
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(css="#contact-forename-field")
	WebElement newPersonFirstName;
	
	@FindBy(css="#contact-surname-field")
	WebElement newPersonLastName;
	
	@FindBy(css="#contact-email-field")
	WebElement newPersonEmailAddress;
	
	@FindBy(css="#contact-phone-field")
	WebElement newPersonPhoneNumber;
	
	@FindBy(css="#contact-unknown-contact-details-true-field")
	WebElement emailOrPhoneUnknown;
	
	@FindBy(css="#contact-under-18-true-field")
	WebElement yesUnder18;
	
	@FindBy(css="#contact-under-18-field")
	WebElement noUnder18;
	
	@FindBy(css="#contact-country-of-residence-england-field")
	WebElement England;
	
	@FindBy(css="#contact-country-of-residence-wales-field")
	WebElement Wales;
	
	@FindBy(css="#contact-country-of-residence-scotland-field")
	WebElement Scotland;
	
	@FindBy(css="#contact-country-of-residence-northern-ireland-field")
	WebElement northernIreland;
	
	@FindBy(css="#contact-country-of-residence-not-sure-field")
	WebElement notSure;
	
	@FindBy(css="#contact-scenario-direct-field")
	WebElement directContact;
	
	@FindBy(css="#contact-scenario-proximity-field")
	WebElement closeContact;
	
	@FindBy(css="#contact_date_of_contact_3i")
	WebElement dayofContact;
	
	@FindBy(css="#contact_date_of_contact_2i")
	WebElement monthofContact;
	
	@FindBy(css="#contact_date_of_contact_1i")
	WebElement yearofContact;
	
	//continueFromWelcome will work
	
	public void enterNewPersonFirstName(String firstname)
	{
		newPersonFirstName.sendKeys(firstname);
	}
	
	public void enternewPersonLastName(String lastName)
	{
		newPersonLastName.sendKeys(lastName);
	}
	
	public void enterEmailAddress(String emailAddress)
	{
		newPersonEmailAddress.sendKeys(emailAddress);
	}
	
	public void enterNewPersonPhoneNumber(String phonenumber)
	{
		newPersonPhoneNumber.sendKeys(phonenumber);
	}
	
	public void selectemailOrPhoneUnknown()
	{
		emailOrPhoneUnknown.click();
	}
	
	public void Under18(String option)
	{
		if(option.equalsIgnoreCase("Yes"))
		{
			yesUnder18.click();
		}
		else if(option.equalsIgnoreCase("No"))
		{
			noUnder18.click();
		}
	}
	
	public void enterCountry(String country)
	{
		if(country.equalsIgnoreCase("England"))
		{
			England.click();
		}
		else if(country.equalsIgnoreCase("Wales"))
		{
			Wales.click();
		}
		else if(country.equalsIgnoreCase("Scotland"))
		{
			Scotland.click();
		}
		else if(country.equalsIgnoreCase("Northern Ireland"))
		{
			northernIreland.click();
		}
		else if(country.equalsIgnoreCase("Not Sure"))
		{
			notSure.click();
		}
	}
	
	public void describeExposure(String option)
	{
		if(option.equalsIgnoreCase("Direct contact"))
		{
			directContact.click();
		}
		else if(option.equalsIgnoreCase("Close contact"))
		{
			closeContact.click();
		}
	}
	
	public void enterDateOfContact(String day,String month,String year)
	{
		dayofContact.sendKeys(day);
		monthofContact.sendKeys(month);
		yearofContact.sendKeys(year);
	}
}
