package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

public class BookHomeTestScreenpageObjects extends HomeScreenObjects
{

	public BookHomeTestScreenpageObjects(WebDriver driver) throws IOException 
	{
		super(driver);
	}

}
