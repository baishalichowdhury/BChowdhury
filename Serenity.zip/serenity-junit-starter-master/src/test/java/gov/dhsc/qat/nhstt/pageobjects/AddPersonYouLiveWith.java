package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AddPersonYouLiveWith extends MainScreenObjects
{
	
public AddPersonYouLiveWith(WebDriver driver) throws IOException 
{
		super(driver);
}

@FindBy(css="#main-content > div > div > div.govuk-\\!-margin-top-8 > button.govuk-button--secondary.govuk-button")
WebElement addpersonyoulivewith;

public void selectAddPersonYouLiveWith()
{
	addpersonyoulivewith.click();
}

}
