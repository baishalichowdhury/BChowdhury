package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class SymptomsCheckerScreenObjects extends MainScreenObjects
{
	public SymptomsCheckerScreenObjects(WebDriver driver) throws IOException 
	{
		super(driver);
	}

	@FindBy (xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[1]/android.widget.CheckBox")
	WebElement tempCheckbox;
	
	@FindBy (xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[2]/android.widget.CheckBox")
	WebElement coughChkBx;
	
	@FindBy (xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.ScrollView/android.widget.LinearLayout/androidx.recyclerview.widget.RecyclerView/android.view.ViewGroup[3]/android.widget.CheckBox")
	WebElement smelltasteLossChkBx1;
	
	@FindBy(xpath="//android.widget.CheckBox[@text='A new loss or change to your sense of smell or taste']")
	WebElement smelltasteLossChkBx;
	
	@FindBy (id="uk.nhs.covid19.internal:id/buttonReviewSymptoms")
	WebElement continueBtn;
	
	
	
	public void marktempCheckbox() 
	{	
		tempCheckbox.click();
	}
	
	public void markcoughChkBx() 
	{	
		coughChkBx.click();
	}
	
	public void marksmelltasteLossChkBx() 
	{	
		smelltasteLossChkBx.click();
	}
	
	public void clickcontinueBtn() 
	{	
		continueBtn.click();
	}

}
