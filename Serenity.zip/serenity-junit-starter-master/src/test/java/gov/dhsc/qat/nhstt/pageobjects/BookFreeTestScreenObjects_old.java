package gov.dhsc.qat.nhstt.pageobjects;

import static io.appium.java_client.touch.offset.PointOption.point;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class BookFreeTestScreenObjects_old extends MainScreenObjects
{
	WebDriverWait wait;
	static Set<String> contextNames;
	
	@FindBy(id="uk.nhs.covid19.internal:id/orderTest")
	WebElement bookFreeTestNowbtn;
	
//	@FindBy(xpath="//*[@id="pilot-option-2"]")
//	WebElement partoftrialproject;
	
//	@FindBy(css="#pilot-option-2")
//	WebElement notpartoftrialproject;
	
	@FindBy(css="#test-reason")
	WebElement testreasonlocalcouncilasked;
	
	@FindBy(css="#test-reason-4")
	WebElement testreasonnoneofabove;
		
	@FindBy(xpath = "//*[@id=\"first-name\"]")
	WebElement firstname;
	
	@FindBy(xpath="//*[@id=\"last-name\"]")
	WebElement lastname;
	
	@FindBy(css="input[class='govuk-radios__input'][value='true']")
	WebElement mobileoption;
	
	@FindBy(css="input[class*='govuk-input'][id='mobile']")
	WebElement mobilenumber;
	
	@FindBy(css="input[class='govuk-radios__input'][value='true']")
	WebElement emailoptn;
	
	@FindBy(css="input[class*='govuk-input'][id='email']")
	WebElement emailaddress;
	
	@FindBy(css="#email-available")
	WebElement emailavl;
	
	@FindBy(css="#email")
	WebElement emailaddress1;
	
	@FindBy(css="input[id='date-day']")
	WebElement dateofsymptoms;
	
	@FindBy(css="input[id='date-month']")
	WebElement monthofsymptoms;
	
	@FindBy(css="input[id='date-year']")
	WebElement yearofsymptoms;
	
	@FindBy (css="input[class='govuk-radios__input'][value='true']")
	WebElement vehicleavailableoption;
	
	@FindBy (xpath = "//*[@id=\"car-accessibility-2\"]")
	WebElement vehiclenotavailableoption;
	
	@FindBy (xpath = "//android.widget.RadioButton[(@resource-id='car-accessibility-2')]")
	WebElement vehiclenotavailableoption1;
					
//	@FindBy(id="chosen-channel-4")
	@FindBy(css="input[value='antigen-walkin']")
	WebElement walkthroughsitebtn;
	
//	@FindBy(id="chosen-channel")
	@FindBy(xpath="//*[@id=\"chosen-channel\"]")
	WebElement drivethroughsitebtn;	
	
//	@FindBy(id="chosen-channel-6")
	@FindBy(css="#chosen-channel-4")
	WebElement hometestingbtn;
//	@FindBy(xpath="//*[@id='chosen-channel-4']")
	
	
	@FindBy(css="input[id='date-day']")
	WebElement datebox;
	
	@FindBy(css="input[id='date-month']")
	WebElement monthbox;
	
	@FindBy(css="input[id='date-year']")
	WebElement yearbox;

	@FindBy(css="input[value*='no']")
	WebElement landlinenotavl;
	
	@FindBy(css="#landline-available")
	WebElement landlineavl;
	
	@FindBy(css="#landline")
	WebElement landlinenumber;
	
	@FindBy(xpath="//*[@id=\"gender\"]")
	WebElement gendermale;
	
	@FindBy(xpath="//*[@id=\"gender-2\"]")
	//@FindBy(css="#gender-2")
	WebElement genderfemale;
	
	@FindBy(xpath="//*[@id=\"ethnicity-group-7\"]")
	WebElement ethnicitygroup;
	
	
	@FindBy(xpath="//*[@id='currently-working']")
	WebElement yesWorkingFromHome;
	
	@FindBy(xpath="//*[@id=\"currently-working-3\"]")
	WebElement currentlynotinwork;
	
	@FindBy(css="#currently-working-2")
	WebElement currentlytravelledtowork;
	
	@FindBy(css="#currently-working-5")
	WebElement currentworkprefernottosay;
	
	@FindBy(css="#industry-4")
	WebElement areaofworkretail;
	
	@FindBy(css="#industry-14")
	WebElement areaofworkprefernottosay;
	
	@FindBy(xpath="//*[@id=\"country\"]")
	WebElement countryengland;
	
	@FindBy(xpath="//*[@id='country-2']")
	WebElement countryScotland;
	
	@FindBy(xpath="//*[@id=\"country-3\"]")
	WebElement countryNorthernIreland;
	
	@FindBy(xpath="//*[@id=\"country-4\"]")
	WebElement countryWales;
	
	@FindBy(css="#country-4")
	WebElement countrywales;
	
	@FindBy(xpath="//*[@id=\"nhs-number-option\"]")
	WebElement nhsnumberoption;
		
	@FindBy(xpath="//*[@id=\"nhs-number\"]")
	WebElement nhsnumber;
		
	@FindBy(css="input[id='postcode']")
	WebElement postcode;
		
	@FindBy(xpath="//*[@id='postcode-number']")
	WebElement postcodeTestSite;
	
	@FindBy(css="#main-content > div > div > section:nth-child(2) > dl > div:nth-child(1) > dd.govuk-summary-list__actions > a")
	WebElement changetestsite;
	
	@FindBy(css="#main-content > div > div > div:nth-child(2) > div:nth-child(6) > a")
	WebElement changetowalkthrough;
	
	@FindBy(css="#main-content > div > div > section:nth-child(2) > dl > div:nth-child(2) > dd.govuk-summary-list__actions > a")
	WebElement changedateandtime;
	
	@FindBy(css="#main-content > div > div > a")
	WebElement startnowregisterkitjourney;
	
	public void selectStartNowRegisterKitJourney()
	{
		startnowregisterkitjourney.click();
	}
	
	public void selectChangeTestSite()
	{
		waitforelement(changetestsite);
		changetestsite.click();
	}
	public void selectChangeToWalkthrough()
	{
		waitforelement(changetowalkthrough);
		changetowalkthrough.click();
	}
	
	public void AddPostcodeOfTestSite(String postcode)
	{
		waitforelement(postcodeTestSite);
		postcodeTestSite.sendKeys(postcode);
		ContinueWeb.click();
	}
	
	
	
//	@FindBy(id="postcode-number")
	@FindBy(xpath="//*[@id=\"postcode-number\"]")
	WebElement POST_CODE_INPUT;
	
	@FindBy(css="button[type='submit']")
	WebElement checkanswers;
	
//	@FindBy(xpath="//android.view.View[contains(@resource-id,'main-content')]")
	@FindBy(css="#main-content > div > div > h1")
	WebElement confirmDetails;
	
	@FindBy(css="#main-content > div > div.govuk-grid-column-two-thirds.paddingless-mobile > div > h1")
	WebElement appointmentconfirmdetails;
	
	@FindBy(xpath="(//div[@class='govuk-summary-list__row' and dt[contains(text(), 'Date and time')]])//dd")
	WebElement dateAndTimeSlot;
	
//	@FindBy(xpath="(//android.widget.RadioButton[contains(@id,'test-centre')]")
//	@FindBy(xpath="//*[@id=\"test-centre\"]")
//	css = #test-centre
	@FindBy(css="#test-centre-2")
	//@FindBy(css="div input[value='XBR']")
	WebElement siteAvailable2;       
	
	@FindBy(css="#test-centre")
	WebElement siteAvailable; 
//	@FindBy(xpath="//android.widget.Button[contains(@text ='Find a test site')]")
//	@FindBy(xpath="//*[@id=\\\"main-content\\\"]/div/div/form/button")
	@FindBy(css="#main-content > div > div > form > button")
	WebElement Continuefromchoosesite;
	
	@FindBy(css="button[class*='govuk-button']")
	WebElement Continue;
	
	@FindBy(xpath="//*[@id='main-content']/div/div/form/button")
	WebElement ContinueWeb;
	
	@FindBy(css="#main-content > div > div > button")
	WebElement Continuedrive;	
	
	@FindBy(css="#main-content > div > div > button")
	WebElement orderkitwattoknowcontinue;
	
//	@FindBy(xpath="//android.widget.RadioButton[contains(@resource-id ,'time')]")
	@FindBy(css="#time")
	List<WebElement> timeslot;
	
	@FindBy(css="#vehicle-registration")
	WebElement vehicleregistrationnumber;
	
//	@FindBy(xpath="//android.widget.Button[contains(@text= 'Save and continue')]")
	@FindBy(css="#main-content > div > div > button")
	WebElement saveAndContiniueAppointmentDetails;
	
//	@FindBy(xpath="//android.widget.TextView[contains(@text= 'View or print pass')]")
	@FindBy(css="#main-content > div > div:nth-child(2) > dl > div:nth-child(1) > dd.govuk-summary-list__actions > a")
	WebElement ViewOrPrintPass;
	
//	@FindBy(xpath="//android.view.View[contains(text(), 'Pass ID')]")
//	@FindBy(css="#main-content > div > div > div.pass > p")
	@FindBy(xpath="//*[@id=\"main-content\"]/div/div/div[1]/p")
	WebElement PassId;
	
//	@FindBy(xpath="//android.widget.Button[(@text='Confirm and continue')]")
//	@FindBy(xpath="//*[@id='screenshotContainer']/div/div/div/div/div/div[34]/div")
	@FindBy(xpath="//*[@id='main-content']/div/div/button")
	WebElement ConfirmAndContinue;
	
	//@FindBy(xpath="//*[@id='screenshotContainer']/div/div/div/div/div/div[37]/div")
	//@FindBy(xpath="//android.widget.Button[(@text='Save and continue')]")
	 @FindBy(xpath="//*[@id='main-content']/div/div/div[3]/button[1]")
	 WebElement SaveAndContinue;
	
//	@FindBy(xpath="//android.view.View[(@text='Confirm people for testing')]")
	@FindBy(xpath="//*[@id='screenshotContainer']/div/div/div/div/div/div[23]/div")
	WebElement Confirmheader;
	
	@FindBy(xpath="//*[@id='submit-delivery-information']")
	WebElement ContinuetoAskMoreQues;
	
	@FindBy(xpath="//*[@id='x-yes-nino']")
	WebElement YestoNINumber;
	
	@FindBy(xpath="//*[@id='nino--4']/input")
	WebElement NINumberText;
	
	@FindBy(xpath="//*[@id='postcode--37']/input")
	WebElement PostCodeforhomeaddress;
	
	@FindBy(xpath="//*[@id='submit-postcode-home']")
	WebElement FindAddress;
	
	@FindBy(xpath="//*[@id='home-address-select-list']/select")
	WebElement HomeAddressPicker;
	
	@FindBy(xpath="//*[@id='x-same-address']")
	WebElement homeSameAsDeliveryYes;
	
	@FindBy(xpath="//*[@id='x-different-address']")
	WebElement homeSameAsDeliveryNo;
	
	//@FindBy(xpath="//*[@id='x-address-check-next']")
	@FindBy(css="#x-address-check-next")
	WebElement ContinueFromHomeAddress;
	
	@FindBy(xpath="//*[@id='3-send-code']")
	WebElement ConfirmEmail;
	
	@FindBy(xpath="//*[@id='postcode--41']/input")
	WebElement DeliveryPostcode;
	
	@FindBy(xpath="//*[@id='root']/main/div/div/div[2]/div/form/div/h2[2]")
	WebElement FindDeliveryaddress;
	
	@FindBy(xpath="//*[@id='delivery-address-select-list']/select")
	WebElement DeliveryAddressPicker;
	
	@FindBy(xpath="//*[@id='delivery-address-submit']")
	WebElement DeliveryAddressContinue;
	
	//@FindBy(xpath="//*[@id='condition']")
	//@FindBy(css="#condition")
	@FindBy(css="div[class='govuk-radios__item'] input[id='condition']")
	WebElement YesCoronaSymptom;
	
	@FindBy(css="#global-cookie-message > div:nth-child(1) > div > div > div.cookie-banner__buttons > button")
	WebElement closecookies;
	
	public void closeCookies()
	{
		closecookies.click();
	}
	
	public void ClickHavingCoronaSymptom() throws InterruptedException
	{
			
	//	waitforelement(YesCoronaSymptom);
		YesCoronaSymptom.click();
         ContinueWeb.click();
	}
	
	@FindBy(css="#pilot-option")
	WebElement partoftrialproject;
//	@FindBy(css="div[class='govuk-radios__item'] input[id='pilot-option-2']")
//	@FindBy(xpath="/html/body/div/div[2]/main/div/div/div[2]/form/div/fieldset/div/div[2]/input[2]")
	@FindBy(css="pilot-option-2")
	WebElement notpartoftrialproject;
	@FindBy(css="#main-content > div > div > h1")
	WebElement partoftrialorgovprojecttitle;
	

	
	@FindBy(css="#main-content > div > div > h1")
	WebElement tetreasontitle;
	public void whyAreYouAskingForTest(String reasonfortest) throws InterruptedException
	{
		waitforelement(tetreasontitle);
		MainScreenObjects_old.swipeToBottom();
		if (reasonfortest.equalsIgnoreCase("Local council asked"))
		{
			waitforelement(testreasonlocalcouncilasked);
			testreasonlocalcouncilasked.click();
		}
		else if(reasonfortest.equalsIgnoreCase("None above"))
		{
			waitforelement(testreasonnoneofabove);
			testreasonnoneofabove.click();
		}
		MainScreenObjects_old.swipeToBottom();
		Continue.click();
	}
	
	public void SelectDeliveryAddress(String houseno)
	{
		Select select= new  Select(DeliveryAddressPicker);
		select.selectByValue(houseno);
		DeliveryAddressContinue.click();
	}
	
	public void clickonFinddeliveryAddress()
	{
		FindDeliveryaddress.click();
	}
	
	public void enterDeliveryPostCode(String deliverypostcode)
	{
		DeliveryPostcode.sendKeys(deliverypostcode);
	}
	public void confirmEmail()
	{
		ConfirmEmail.click();
	}
	
	public void selectYesToHomeAddressSameasDelivery(String option)
	{
		if(option.equalsIgnoreCase("Yes"))
		{
		homeSameAsDeliveryYes.click();	
		}
		else if(option.equalsIgnoreCase("No"))
		{
			homeSameAsDeliveryNo.click();
		}
		ContinueFromHomeAddress.click();
	}
	
	@FindBy(xpath="//*[@id='home-address-submit']")
	WebElement ContinueHomeAddress;
	public void selectAddress(String value)
	{
		waitforelement(HomeAddressPicker);
		Select select= new Select(HomeAddressPicker);
		select.selectByValue(value);
		ContinueHomeAddress.click();
	}
	
	public void clickonFindAddress()
	{
		waitforelement(FindAddress);
		FindAddress.click();
	}
	
	public void Enterpostcodeforhomeaddress(String postcode)
	{
		/*waitforelement(PostCodeforhomeaddress);
		PostCodeforhomeaddress.clear();
		PostCodeforhomeaddress.sendKeys(postcode);*/
	}
	@FindBy(xpath="//*[@id='2-next-details-top']")
	WebElement ContinueNINum;
	public void EnterNINumber(String NINumber)
	{
		NINumberText.sendKeys(NINumber);
		ContinueNINum.click();
	}
	@FindBy(xpath="//*[@id='2-next-details-top']")
	WebElement ContinueNI;
	public void doYouKnowNINumber(String option)
	{
		if(option.equalsIgnoreCase("Yes"))
		{
		YestoNINumber.click();
	//	NINumberText.sendKeys("SY717044C");
	//	waitforelement(ContinueNI);
		ContinueWeb.click();
		}
		else if(option.equalsIgnoreCase("No"))
		{
			NONINum.click();
			waitforelement(ContinueNI);
			ContinueNI.click();
		}
	}
	
	public void clickOnContinuetoaskMoreQues()
	{
		waitforelement(ContinuetoAskMoreQues);
		ContinuetoAskMoreQues.click();
	}
	
	public String getConfirmHeader()
	{
		return(Confirmheader.getText());
	}
	
	public void ClickonSaveAndcontinue()
	{
		SaveAndContinue.click();
	}
	
	
	@FindBy(xpath="//*[@id='main-content']/div/div/div[3]/button[2]")
	WebElement AddPersonYouLiveWith;
	
	public void clickonAddPerson()
	{
		AddPersonYouLiveWith.click();
	}
	
	public void ClickonConfirmandcontinue()
	{
		//waitforelement(ConfirmAndContinue);
		//ConfirmAndContinue.sendKeys(Keys.ENTER);
		ConfirmAndContinue.click();
	}
	
	public void clickOnBookFreeTestNow()
	{
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
		bookFreeTestNowbtn.click();
	}
	public void waitforelement(WebElement element)
	{
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public void waitforsecuritycheck(WebElement el)
	{
		WebDriverWait wait = new WebDriverWait(driver, 240);
		wait.until(ExpectedConditions.visibilityOf(el));
	}
	
	public void firstNamelastNameScreen(String firstName, String lastName) throws InterruptedException
	{
	
	waitforelement(firstname);
	firstname.sendKeys(firstName);
	lastname.sendKeys(lastName);
	ContinueWeb.click();
	
	}
	public void selectMobile(String option)
	{
		if(option.equalsIgnoreCase("Yes"))
		{
		mobileoption.click();
		}
	}
	public void selectMobile()
	{
		mobileoption.click();
	}
	public void enterMobileNumber(String mobileNumber) throws InterruptedException
	{
		waitforelement(mobilenumber);
		mobilenumber.sendKeys(mobileNumber);
		ContinueWeb.click();
		Thread.sleep(10);
	}
	@FindBy(xpath="//*[@id='mobile-confirmation']")
	WebElement confirmmobile;
	public void ConfirmMobileNumber(String num)
	{
		confirmmobile.sendKeys(num);
		ContinueWeb.click();
	}
	
	public void selectEmailoption(String option)
	{
		if(option.equalsIgnoreCase("Yes"))
		{	
		emailoptn.click();
		}
	}
	public void selectEmailoption()
	{
		emailoptn.click();     
	}
	public void enterEmailAddress(String email) throws InterruptedException
	{
		waitforelement(emailaddress);
		emailaddress.clear();
		emailaddress.sendKeys(email);
		ContinueWeb.click();
		Thread.sleep(10);
	}

	public void enterSymptomsStartDate(String startdate, String startmonth,String startyear ) throws InterruptedException
	{
		
		dateofsymptoms.sendKeys(startdate);
		monthofsymptoms.sendKeys(startmonth);
		yearofsymptoms.sendKeys(startyear);
		ContinueWeb.click();
		Thread.sleep(10);
	}
	
  public void clickOnContinue()
  {
	  ContinueWeb.click();
  }
	public void vehicleAccess(String option) throws InterruptedException
	{
		if(option.equalsIgnoreCase("No"))
		{
		vehiclenotavailableoption.click();
		ContinueWeb.click();
		Thread.sleep(10);
		}
		else if(option.equalsIgnoreCase("Yes"))
		{
			vehicleavailableoption.click();
			ContinueWeb.click();
			Thread.sleep(10);
		}
	}
	public void checkSelectedAnswers() throws InterruptedException
	{
		checkanswers.click();
	    waitforsecuritycheck(ContinueWeb);
	}
	
	public void clickOnWalkThroughSite() throws InterruptedException
	{
		walkthroughsitebtn.click();
		System.out.println(walkthroughsitebtn.getText());
		ContinueWeb.click();
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	/*	MainScreenObjects_old.swipeToBottom();
		try{
		ContinueWeb.click();
		}
		catch(Exception e)
		{
			ConfirmAndContinue.click();
		}*/
	
	}
	public void clickOnDriveThroughSite() throws InterruptedException
	{
		MainScreenObjects_old.swipeToBottom();
		drivethroughsitebtn.click();
		MainScreenObjects_old.swipeToBottom();
		ContinueWeb.click();
	}
	
	public boolean drivethroughoptionavailability()
	{
		Boolean b=drivethroughsitebtn.isEnabled();
		return b;
	}
	
	@FindBy(css="#main-content > div > div > form > div.govuk-form-group > fieldset > div > div:nth-child(2)")
	WebElement drivethroughtext;
	
	public String getDriveThroughText()
	{
		String text=drivethroughtext.getText();	
		return text;
	}
	
	
	public void clickOnHomeTesting() throws InterruptedException
	{
		MainScreenObjects_old.swipeToBottom();
		hometestingbtn.click();
		ContinueWeb.click();
	}
	
	@FindBy(xpath="//*[@id='recaptcha-anchor']/div[1]")
	WebElement Securitycheck;
	
	public void clickOnSecuritycheck()
	{
		/*Securitycheck.click();
		ContinueWeb.click();*/
	}
	
	@FindBy(css="#main-content > div > div > h1")
	WebElement screenText;
	
	public String getScreenText()
	{
		return(screenText.getText());
	}
	@SuppressWarnings("rawtypes")
	public void readAdviceForVisitingDrive() throws InterruptedException
	{
		MainScreenObjects_old.swipeToBottom();
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	MainScreenObjects_old.swipeToBottom();		
		ContinueWeb.click();
			
	}
	
	@SuppressWarnings("rawtypes")
	public void orderHomeTestKitWhattoKnow() throws InterruptedException
	{
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	MainScreenObjects_old.swipeToBottom();		
	//	Continue.click();
		orderkitwattoknowcontinue.click();
			
	}	
	public void enterDOB(String date,String month,String year)
	{
		datebox.sendKeys(date);
		monthbox.sendKeys(month);
		yearbox.sendKeys(year);
		
		ContinueWeb.click();
	}
	
	public void landlineNotAvailabile() throws InterruptedException
	{
		landlinenotavl.click();
		System.out.println(landlinenotavl.getText());
		ContinueWeb.click();
	}
	
	public void landlineavailable()
	{
		landlineavl.click();
		landlinenumber.sendKeys("landlinenumber");
		ContinueWeb.click();
	}
	
	public void selectGender(String Gender)
	{
		waitforelement(ContinueWeb);
		if(Gender.equalsIgnoreCase("Male"))
		{
		gendermale.click();
		}
		else if(Gender.equalsIgnoreCase("Female"))
		{
			genderfemale.click();
		}
		ContinueWeb.click();
	}
	
	@FindBy(xpath="//*[@id='postcode-option']")
	WebElement PostCodeSame;
	@FindBy(css="#postcode-option-2")
	WebElement someWhereElse;
	@FindBy(css="#postcode")
	WebElement differentPostcode;
	public void clickPostCodeSameorSomewhereelse(String option)
	{
		if(option.equalsIgnoreCase("Same"))
		{
			PostCodeSame.click();
			ContinueWeb.click();
		}
		
		else if(option.equalsIgnoreCase("Somewhere else"))
		{
			someWhereElse.click();
			waitforelement(differentPostcode);
			
		}
		
	}
	public void enterDifferentPostcode(String postcode)
	{
		differentPostcode.sendKeys(postcode);
		ContinueWeb.click();
	}
	public void clickPostCodeSame()
	{
		PostCodeSame.click();
		ContinueWeb.click();
	}
	
	@FindBy(xpath="//*[@id='ethnicity-group']")
	WebElement asian;
	
	@FindBy(css="#ethnicity-group-2")
	WebElement blackAfrican;
	public void enterEthnicityGroup(String Ethnicgroup)
	{
		if(Ethnicgroup.equalsIgnoreCase("Prefer not to say"))
		{
	
		ethnicitygroup.click();
		}
		else if(Ethnicgroup.equalsIgnoreCase("Asian or Asian british"))
		{
			asian.click();
		}
		else if(Ethnicgroup.equalsIgnoreCase("Black African"))
		{
			blackAfrican.click();
		}
		ContinueWeb.click();
	}
	//@FindBy(xpath="//*[@id='ethnicity-3']")
	@FindBy(css="#ethnicity-3")
	WebElement backgroundIndian;
	
	@FindBy(css="#ethnicity")
	WebElement africanBackground;
	
	@FindBy(css="#ethnicity-4")
	WebElement backgroundpakistani;
	
	@FindBy(css="#ethnicity-4")
	WebElement PakistaniBackground;
	public void background(String background)
	{
		if(background.equalsIgnoreCase("Indian"))
		{
			backgroundIndian.click();
		}
		else if(background.equalsIgnoreCase("African"))
		{
			africanBackground.click();
		}
		else if(background.equalsIgnoreCase("Pakistani"))
		{
			PakistaniBackground.click();
		}
		ContinueWeb.click();
	}
	
	public void asianBackground(String background) throws InterruptedException
	{
		MainScreenObjects_old.swipeToBottom();
		if(background.equalsIgnoreCase("Indian"))
		{
			backgroundIndian.click();
		}
		else if(background.equalsIgnoreCase("Pakistani"))
		{
			backgroundpakistani.click();
		}
		MainScreenObjects_old.swipeToBottom();
		ContinueWeb.click();
	}
	public void currentWorkStatus(String option)
	{
		if(option.equalsIgnoreCase("No"))
		{
		currentlynotinwork.click();
		}
		else if(option.equalsIgnoreCase("Yes Travelled"))
		{
			currentlytravelledtowork.click();
		}
		else if(option.equalsIgnoreCase("Yes Working from home"))
		{
			yesWorkingFromHome.click();
		}
		ContinueWeb.click();
		
	}
	
	public void currentWorkStatusNo()
	{
		currentlynotinwork.click();
		ContinueWeb.click();
		
	}
	
	public void currentWorkStatusYes()
	{
		currentlytravelledtowork.click();
		ContinueWeb.click();
	}
	
	public void currentWorkStatusPreferNotToSay()
	{
		currentworkprefernottosay.click();
		ContinueWeb.click();
	}
	
	@FindBy(css="#industry-2")
	WebElement healthAndSocialCare;
	
	@FindBy(css="#industry-4")
	WebElement retail;
	
	public void areaOfWork(String workarea)
	{
	if(workarea.equalsIgnoreCase("Retail"))	
	{
		retail.click();
	}
	else if(workarea.equalsIgnoreCase("Health and social care"))	
	{
		healthAndSocialCare.click();
	}
	ContinueWeb.click();
	}
	
	@FindBy(css="#occupation")
	WebElement occupation;
	
	@FindBy(xpath="//*[@id='main-content']/div/div/form/div/fieldset/div/ul/li[1]")
	WebElement suggetsedoccupation;
	
	public void enterOccupation(String occupationname)
	{
		occupation.sendKeys(occupationname);
		waitforelement(suggetsedoccupation);
		suggetsedoccupation.click();
		ContinueWeb.click();
	}
	
	public void areaOfWorkPreferNotToSay() throws InterruptedException
	{
		MainScreenObjects_old.swipeToBottom();
		areaofworkprefernottosay.click();
		ContinueWeb.click();
		
	}
	
	public void partOfTrialOrGovernmentProject(String trialproject) throws InterruptedException
	{
	MainScreenObjects_old.swipeToBottom();
	if(trialproject.equalsIgnoreCase("Yes"))
	{
	partoftrialproject.click();
	}
	else if(trialproject.equalsIgnoreCase("No"))
	{
		notpartoftrialproject.click();
		
	}
	MainScreenObjects_old.swipeToBottom();
	Continue.click();
	}
	
	@FindBy(css="#employer")
	WebElement employer;
	public void enterEmployer(String employername)
	{
		employer.sendKeys(employername);
		ContinueWeb.click();
	}
	
	public void areaOfWorkRetail() throws InterruptedException
	{
		MainScreenObjects_old.swipeToBottom();
		areaofworkretail.click();
		MainScreenObjects_old.swipeToBottom();
		ContinueWeb.click();
		
	}
	
	@FindBy(xpath="//*[@id='main-content']/div/div/form/form/button")
	WebElement ContinueCountry;
	public void countryOfResidence(String country)
	{
		if(country.equalsIgnoreCase("England"))
		{
		countryengland.click();
		}
		else if(country.equalsIgnoreCase("Scotland"))
		{
			countryScotland.click();
		}
		else if(country.equalsIgnoreCase("Northern Ireland"))
		{
		countryNorthernIreland.click();
		}
		else if(country.equalsIgnoreCase("Wales"))
		{
			countryWales.click();
		}
		ContinueCountry.click();
	}
	public void countryOfResidenceWales()
	{
		countrywales.click();
		ContinueWeb.click();
	 
	}
	@FindBy(css="#nhs-number-option-2")
	WebElement DontKnowNHS;
	public void nhsnumberAvailability(String option)
	{
		if(option.equalsIgnoreCase("Yes"))
		{
		nhsnumberoption.click();
		}
		else if(option.equalsIgnoreCase("No"))
		{
			DontKnowNHS.click();	
		}
		ContinueWeb.click();
	}
	
	@FindBy(xpath="//*[@id='main-content']/div/div/div[1]/h1")
	WebElement TestKitRegistrationConfirm;
	
	public String TestKitRegistrationConfirmationMessage()
	{
		waitforsecuritycheck(TestKitRegistrationConfirm);
		return(TestKitRegistrationConfirm.getText());
	}
	public void enternhsnumber(String NHSNumber)
	{
		nhsnumber.sendKeys(NHSNumber);
		ContinueWeb.click();
	}
	
	public void nhsnumber(String NHSNumber)
	{
		nhsnumber.sendKeys(NHSNumber);
		ContinueWeb.click();
	}
	
	
	@FindBy(xpath="/html/body/div/div[2]/main/div/div/button")
	WebElement CheckyourAnsContinue;
	
	@FindBy(css="body > div > div > main > div > div > button")
	WebElement checkAnsSaveandContinue;
	public void verifyAnswers()
	{
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	MainScreenObjects_old.swipeToBottom(); 
		try
		{
		CheckyourAnsContinue.click();
		}
		catch(Exception e)
		{
			checkAnsSaveandContinue.click();
		}
	}
		
	 public void enterPostcode(String PostCode) 
	 {
		 waitforelement(postcode);
		 postcode.clear();
		 postcode.sendKeys(PostCode);
		 ContinueWeb.click();
		 
	    }
	 public void enterPostcodeTestsite(String postcode) 
	 {
		 POST_CODE_INPUT.clear();
		 POST_CODE_INPUT.sendKeys(postcode);
		 Continuefromchoosesite.click();
	    }
	 
	 public void enterPostcodeTestsite() 
	 {
		 waitforelement(POST_CODE_INPUT);
		 POST_CODE_INPUT.clear();
		 POST_CODE_INPUT.sendKeys(prop.getProperty("postcode"));
		 Continuefromchoosesite.click();
	    }
	 
	 public void validateAppointmentConfirmationMessage()
	 {
		 String CONFIRM_APPOINTMENT = "Confirm your appointment";
		 wait = new WebDriverWait(driver, 10);
		 wait.until(ExpectedConditions.visibilityOf(confirmDetails));  
		 String Message= confirmDetails.getText();
		Assert.assertTrue(Message.contains(CONFIRM_APPOINTMENT));

	 }
	 
	
	 public void confirmAppointmentDetails() throws InterruptedException 
	 { 
		saveAndContiniueAppointmentDetails.click();
	    }
	 
	 public void chooseTestSite(String option) throws InterruptedException 
	 { 
		
		 if(option.equalsIgnoreCase("first"))
		 {
		  
		 }
		 else if(option.equalsIgnoreCase("second"))
		 {
			 
		 }
		 Thread.sleep(2000);
		 siteAvailable2.click();
		// Thread.sleep(7000);
	     ContinueWeb.click();
	     
     }
	 
	 public void chooseTestSite() throws InterruptedException 
	 { 
		 
		 wait = new WebDriverWait(driver, 10);
		 wait.until(ExpectedConditions.visibilityOf(postcodedisplay)); 
		 MainScreenObjects_old.swipeToBottom2();
		 System.out.println("SwipetoBottom");
	//	 new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	 WebElement site= siteAvailable.get(0);
		// wait = new WebDriverWait(driver, 10);
		 //wait.until(ExpectedConditions.visibilityOf(siteAvailable));
		 siteAvailable.click();
	//	 wait.until(ExpectedConditions.visibilityOf(site));
	//	 site.click();
	     ContinueWeb.click();
	     
     }
	 
	 @FindBy (css = "#main-content > div > div > div:nth-child(2) > div:nth-child(3) > span") 
		WebElement postcodedisplay;
	 @FindBy(css="#global-cookie-message > div:nth-child(1) > div > div > div.cookie-banner__buttons > button")
	 WebElement acceptCookies;
	 
	 public void clickOnAcceptCookies()
	 {
		 if(acceptCookies.isDisplayed())
		 {
			 acceptCookies.click();
		 }
		 System.out.println("Cookies accepted");
	 }
	 
	 @FindBy(css="#main-content > div > div > h1")
	 WebElement timeslotdisplay;
	 
	 @FindBy(css="#main-content > div > div > div.govuk-grid-row.govuk-\\!-margin-top-5 > div > form > button.govuk-\\!-margin-right-5.govuk-button")
	 WebElement continuetimeslot;
	 @FindBy(css="#main-content > div > div.govuk-grid-column-two-thirds.paddingless-mobile > div > h1")
	 WebElement AppointmentBooked;
	 
	 public void VerifyAppointmentBookedText()
	 {
		String Appointment_booked="Appointment booked";
		waitforelement(AppointmentBooked);
		String actual=AppointmentBooked.getText();
		Assert.assertTrue(actual.contains(Appointment_booked));
	 }
	 
	 @FindBy(xpath="//*[@id='main-content']/div/div/div[3]/div/form/div/fieldset/p/a")
	 WebElement seeNextDay;
	 
	 @FindBy(xpath="/html/body/div/div[2]/main/div/div/div[3]/div/form/div/fieldset/div[2]/div/div/input")
	 List<WebElement> timeslots;
	 
	// @FindBy(xpath="//*[@id='time']")
	 @FindBy(css="#time")
	 WebElement firsttimeslot;
	 
	 @FindBy(xpath="//*[@id='main-content']/div/div/div[3]/div/form/button[1]")
	 WebElement continueTimeSlot;
	 public void selectTimeSlot(String slot) throws InterruptedException
	 {
		Thread.sleep(2000);
		if(slot.equalsIgnoreCase("first"))
		{
		 firsttimeslot.click();
		}
		
		
		 /*JavascriptExecutor executor = (JavascriptExecutor) driver;
		 executor.executeScript("arguments[0].scrollIntoView(true);", continueTimeSlot);  */
		 continueTimeSlot.click();
	 }
	 
	 @FindBy(xpath="//*[@id='main-content']/div/div/div[3]/div/form/div/fieldset/div[2]/p[2]")
	 WebElement noslotText;
	 
	 public void clickNextday() throws InterruptedException
	 {
		 Thread.sleep(2000);
		 try{
			 noslotText.getText().contains("no slots available");
			 seeNextDay.click();
		 }
		 catch(Exception e)
		 {
			System.out.println("slots available today... so choosen today slot"); 
		 }
		
	 }
	 public void chooseTimeSlot() throws InterruptedException 
	 { 
	//	 new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	 MainScreenObjects_old.swipeToBottom();
		 
		 WebElement Timeslot= timeslot.get(0);
		 Timeslot.click();
	//	 MainScreenObjects_old.swipeToBottom(); 
	//	 new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
		 ContinueWeb.click();
      }
	 
	 @FindBy(xpath="//*[@id='main-content']/div/div/div[2]/form/button")
	 WebElement vehicleRegistrationContinue;
	 public void vehicleRegistrationNumber(String registrationnumber)
	 {
		 vehicleregistrationnumber.sendKeys(registrationnumber);
		 vehicleRegistrationContinue.click();
	 }
	 
	 public void confirmAppointmnet()
	 {
	//	 new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	 Continue.click(); 
	 }
	 
	 public void confirmAppointmnetBooked() throws InterruptedException
	 {
		 String APPOINTMENT_BOOKED = "Appointment booked";
		 wait.until(ExpectedConditions.visibilityOf(appointmentconfirmdetails));  
		 String Message= appointmentconfirmdetails.getText();
		Assert.assertTrue(Message.contains(APPOINTMENT_BOOKED));
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	 MainScreenObjects_old.swipeToBottom();
		 ViewOrPrintPass.click();
	//	 MainScreenObjects_old.swipeToBottom();
	//	 new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
	//	 String PassID= PassId.getText();
    //     System.out.println(PassID);
		
	 }

	@FindBy(xpath="//*[@id='main-content']/div/div/a")
	WebElement StartNow;
	
	public void clickOnStartNow()
	{
		StartNow.click();
	}
	
	@FindBy(xpath="//*[@id='courierBooked']")
	WebElement KnowReturnTestKit;
	
	public void ClickKnowReturnTestKit()
	{
		KnowReturnTestKit.click();
        ContinueWeb.click();
	}
	
	@FindBy(xpath="//*[@id='journey']")
	WebElement AtTestSite;
	
	public void whereToTakeTest(String location)
	{
		if(location.equalsIgnoreCase("At a test site"))
		{
			AtTestSite.click();
		}
		ContinueWeb.click();
	}
	
	@FindBy(xpath="//*[@id='main-content']/div/div/p[4]/a")
	WebElement DifferentWayLink;
	
	public void clickonDifferentWaylink()
	{
		DifferentWayLink.click();
	}
	
	//@FindBy(xpath="//*[@id='test-centre']")
	// @FindBy(css="#test-centre")
	//@FindBy(xpath="/html/body/div/div[2]/main/div/div/form/div/fieldset/div[1]/div[1]/input")
	@FindBy(css="input[id='test-centre']")
	WebElement TestSite1;
	@FindBy(css="#journey-2")
	WebElement atHome;
	
	public void whereToTakeTest1(String option) throws InterruptedException
	{
		if(option.equalsIgnoreCase("At a test site"))
		{
		
		waitforelement(TestSite1);
		TestSite1.click();
		}
		else if(option.equalsIgnoreCase("Home"))
		{
			atHome.click();
		}
		ContinueWeb.click();
	}
	
	@FindBy(xpath="//*[@id='sample-id']")
	WebElement BarCodeText;
	
	public void EnterBarCode(String barcode)
	{
		BarCodeText.sendKeys(barcode);
	}
	@FindBy(xpath="//*[@id='sample-id-confirm']")
	WebElement ConfirmbarCode;
	public void confirmBarCode(String barcode)
	{
		ConfirmbarCode.sendKeys(barcode);
		ContinueWeb.click();
	}
	@FindBy(xpath="//*[@id='testDateRadioOption']")
	WebElement todaydatetotaketest;
	
	public void selectTimeTotaketest() throws InterruptedException
	{
		Thread.sleep(2000);
		todaydatetotaketest.click();
	}
	@FindBy(xpath="//*[@id='testTimeInput']")
	WebElement Timetotaketest;
	
	@FindBy(css="#testDateRadioOption-3")
	WebElement differentdatetotaketest;
	
	public void selectDifferentTimeToTakeTest()
	{
		differentdatetotaketest.click();
	}
	
	@FindBy(css="#testDate-day")
	WebElement testdateday;
	@FindBy(css="#testDate-month")
	WebElement testmonth;
	@FindBy(css="#testDate-year")
	WebElement testyear;
	public void testDateInput()
	{
		testdateday.sendKeys(prop.getProperty("testdateday"));
		testmonth.sendKeys(prop.getProperty("testmonth"));
		testyear.sendKeys(prop.getProperty("testyear"));
	}
	
	public void timeOfTakingTest(String time)
	{
		Timetotaketest.sendKeys(time);
	}
	@FindBy(xpath="//*[@id='testTimeRadio']")
	WebElement am;
	
	
	
	public void clickampm(String option)
	{
		if(option.equalsIgnoreCase("am"))
		am.click();
		else if(option.equalsIgnoreCase("pm"))
		pm.click();	
		ContinueWeb.click();
	}

	public void clickam()
	{
		am.click();
		ContinueWeb.click();
	}
	@FindBy(css="#testTimeRadio-2")
	WebElement pm;
	
	public void clickpm()
	{
		pm.click();
		ContinueWeb.click();
	}
	
//	@FindBy(css="#recaptcha-anchor > div.recaptcha-checkbox-checkmark")
	
	@FindBy(css="#recaptcha-anchor")
	WebElement recaptchabox;
	@FindBy(css="#main-content > div > div > button")
	WebElement saveandcontinue;
	
	public void selectRecaptchaBox() throws InterruptedException
	{
		waitforelement(recaptchabox);
		recaptchabox.click();
		saveandcontinue.click();
		
	}
	@FindBy(xpath="/html/body/div/div/main/div/div/button")
	WebElement SaveAndContinueYourAns;
	
	public void clickonSaveAndContinueAns()
	{
		SaveAndContinueYourAns.click();
	}
	
	@FindBy(css="#x-no-nino")
	WebElement NONINum;
	
	@FindBy(xpath="//*[@id='main-content']/div/div/div[3]/div/form/div/fieldset/div/p[2]")
	WebElement noSlotText;
	
	public String getTextNoSlot()
	{
		return(noSlotText.getText());
	}
	
	@FindBy(xpath="//*[@id='main-content']/div/div/div[3]/div/form/button[2]")
	WebElement changeTestSite;
	
	public void clickChangeTestSite()
	{
		waitforelement(changeTestSite);
		changeTestSite.click();
	}
	
	@FindBy(css="#order-reference")
	WebElement orderid;
	
	public void enterOrderId(String order)
	{
		orderid.sendKeys(order);
		ContinueWeb.click();
	}
	
	public BookFreeTestScreenObjects_old(WebDriver driver) throws IOException 
	{
		super(driver);
	}
	
	@FindBy(css="button[class*='govuk-button']")
	WebElement continueBtn;
	
	@FindBy(xpath="//*[@id='main-content']/div/div/button")
	WebElement ContinueWhatyouneedtoknow;
	public void clickContinue() {
//	WebElement continueBtn = driver.findElementByCssSelector();
	waitforelement(ContinueWhatyouneedtoknow);	
	ContinueWhatyouneedtoknow.click();
	}
	
	public void changeAppointmentDateAndTime()
	{
		changedateandtime.click();
	}
	
	@FindBy(css="#time-2")
	WebElement differenttime;
	
	public void differentAppointmentDateAndTime() throws InterruptedException
	{
		waitforelement(timeslotdisplay);
		MainScreenObjects_old.swipeToBottom();
		differenttime.click();
		MainScreenObjects_old.swipeToBottom();
		continuetimeslot.click();
	}
	@FindBy(css="#currently-working")
	WebElement currentlyworkingfromhome;
	public void currentlyWorkingFromHome()
	{
		currentlyworkingfromhome.click();
		ContinueWeb.click();
	}
	public void closeWindow()
	{
		driver.close();
	}
}
