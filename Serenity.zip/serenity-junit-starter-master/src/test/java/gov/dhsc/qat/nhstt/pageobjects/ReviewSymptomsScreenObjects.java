package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class ReviewSymptomsScreenObjects extends SymptomsCheckerScreenObjects
{
 public ReviewSymptomsScreenObjects(WebDriver driver) throws IOException
 {
		super(driver);
	}

@FindBy(id= "uk.nhs.covid19.internal:id/textReviewSymptomsTitle")
 WebElement reviewSymptomsTitle;
 
 @FindBy(id= "uk.nhs.covid19.internal:id/checkboxNoDate")
 WebElement unknownDate;
 
 @FindBy(id= "uk.nhs.covid19.internal:id/buttonConfirmSymptoms")
 WebElement submit;
 
 @FindBy(id="uk.nhs.covid19.internal:id/confirm_button")
 WebElement clickdateok;
 
 @FindBy(id="uk.nhs.covid19.internal:id/selectDateContainer")
 WebElement calender;
 
 public String getTextOfreviewSymptoms () 
 {
	 
	 String messge= reviewSymptomsTitle.getText();
	 return(messge);
 }
 
 public void selectunknownDate ()
 {
	 unknownDate.click();
 }
 
 public void clickSubmit ()
 {
	 submit.click();
 }
 
 /*public void selectTodaysDate()
 {
	 calender.click();
	 LocalDate date = LocalDate.now().minusDays(0);
     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, d MMM");
     String text = date.format(formatter);
     String datepicker_xpath = "//android.widget.TextView[@content-desc="+"\""+text+"\"]";
     WebElement clickdate = driver.findElementByXPath(datepicker_xpath);
     clickdate.click();
     clickdateok.click();
 }*/

 
 public void selectDate(int minusdays)
 {
	 calender.click();
	 LocalDate date = LocalDate.now().minusDays(minusdays);
     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, d MMM");
     String text = date.format(formatter);
     String datepicker_xpath = "//android.widget.TextView[@content-desc="+"\""+text+"\"]";
     WebElement clickdate = driver.findElement(By.xpath(datepicker_xpath));
     clickdate.click();
     clickdateok.click();
 }
 
 /*public void selectPastFiveDayDate()
 {
	 calender.click();
	 LocalDate date = LocalDate.now().minusDays(5);
     DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, d MMM");
     String text = date.format(formatter);
     String datepicker_xpath = "//android.widget.TextView[@content-desc="+"\""+text+"\"]";
     WebElement clickdate = driver.findElementByXPath(datepicker_xpath);
     clickdate.click();
     clickdateok.click();
 }*/
 
}
