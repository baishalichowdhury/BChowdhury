package gov.dhsc.qat.nhstt.pageobjects;

import static io.appium.java_client.touch.offset.PointOption.point;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class EthnicityBackgroundScreenObjects extends HomeScreenObjects{
	
public EthnicityBackgroundScreenObjects(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}

//	@FindBy(id="ethnicity")
	@FindBy(css="#ethnicity")
	WebElement ethnicityBritishEnglishNorthernIrishScottishWelsh;
	
	@FindBy(css="#ethnicity-3")
	WebElement ethnicityBackgroundIndian;
	
	@FindBy(css="#ethnicity-4")
	WebElement ethnicityBackgroundPakistani;
	
public void selectEthnicityBackground(String ethnicityBackgroundChosen) throws InterruptedException
{
//	swipeDown();
	if (ethnicityBackgroundChosen.equalsIgnoreCase("British"))
	  { ethnicityBritishEnglishNorthernIrishScottishWelsh.click(); 
	  } 
	  else if(ethnicityBackgroundChosen.equalsIgnoreCase("Indian")) 
	  { ethnicityBackgroundIndian.click(); 
	  } 
	  else if(ethnicityBackgroundChosen.equalsIgnoreCase("Pakistani"))
	  {
		  ethnicityBackgroundPakistani.click();
	  }
		MainScreenObjects.swipeToBottom();
		
	 // clickOnContinue();
	  }

}
