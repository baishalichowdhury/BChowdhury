package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class CTASMoreAboutWhereYouLiveObjects extends HomeScreenObjects
{

	public CTASMoreAboutWhereYouLiveObjects(WebDriver driver) throws IOException 
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(css="#event-exposure-group-field")
	WebElement describePlaceWhereYouLiveIn;
	
	@FindBy(css="#event-exposure-group-field > option:nth-child(2)")
	WebElement childCare;
	
	@FindBy(css="#event-exposure-group-field > option:nth-child(3)")
	WebElement hostel;
		
	@FindBy(css="#event-exposure-group-field > option:nth-child(4)")
	WebElement militaryBlock;
	
	@FindBy(css="#event-exposure-group-field > option:nth-child(5)")
	WebElement other;
	
	@FindBy(css="#event-exposure-group-field > option:nth-child(6)")
	WebElement prison;
	
	@FindBy(css="#event-exposure-group-field > option:nth-child(7)")
	WebElement shelter;
	
	@FindBy(css="#event-address-line-1-field")
	WebElement nameOrNumberOfPlace;
	
	@FindBy(css="#event-town-or-city-field")
	WebElement townOrCity;
	
	@FindBy(css="#event-postcode-field")
	WebElement postCode;
	
	@FindBy(css="#main-content > div > div > div > form > input.nhsuk-button.nhsuk-button--primary")
	WebElement continueMoreAbout;
	
	public void selectOptioDdescribePlaceWhereYouLiveIn(String option)
	{
		Select select = new Select(describePlaceWhereYouLiveIn);
		select.selectByVisibleText(option);
		
	}
	
	public void enterNameNumberOfHouse(String houseno)
	{
		nameOrNumberOfPlace.sendKeys(houseno);
	}
	
	public void enterTownCity(String city)
	{
		townOrCity.sendKeys(city);
	}
	public void enterCasePostCode(String postcode)
	{
		postCode.sendKeys(postcode);
	}
	
	public void continueMoreAboutLiving()
	{
		continueMoreAbout.click();
	}
}
