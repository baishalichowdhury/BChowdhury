package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class AboutThisAppScreenObject extends MainScreenObjects
{

	public AboutThisAppScreenObject(WebDriver driver) throws IOException
	{
		super(driver);
	}
	
	@FindBy(id="uk.nhs.covid19.internal:id/linkManageData")
	WebElement manageMyData;
	
	public void clickOnManageMyData()
	{
		manageMyData.click();
	}

}
