package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASDidYouStayOverNight extends HomeScreenObjects
{

	public CTASDidYouStayOverNight(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(css="#backwards-tracing-state-stayed-overnight-true-field")
	WebElement yesStayed;
	
	@FindBy(css="#backwards-tracing-state-stayed-overnight-field")
	WebElement notStayed;
	
	// continuefromwelcome will work
	
	public void selectStayedOrNotOvernight(String option)
	{
		if(option.equalsIgnoreCase("Yes"))
		{
			yesStayed.click();
		}
		
		else if(option.equalsIgnoreCase("No"))
		{
			notStayed.click();
		}
	}
}
