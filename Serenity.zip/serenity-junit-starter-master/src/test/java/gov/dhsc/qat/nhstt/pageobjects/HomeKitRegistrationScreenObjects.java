package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomeKitRegistrationScreenObjects extends HomeScreenObjects{
	
	public HomeKitRegistrationScreenObjects() throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy (css="#order-reference")
	WebElement orderid;

	@FindBy(css="#main-content > div > div > form > button")
	WebElement Continue;
	
public void enterOrderId() throws InterruptedException
{
	orderid.sendKeys(prop.getProperty("orderid"));
	Continue.click();
}

}
