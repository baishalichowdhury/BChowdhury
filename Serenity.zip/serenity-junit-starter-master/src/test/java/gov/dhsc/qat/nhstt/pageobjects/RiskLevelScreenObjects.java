package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class RiskLevelScreenObjects extends MainScreenObjects
{

	public RiskLevelScreenObjects(WebDriver driver) throws IOException 
	{
		super(driver);
	}
	
	
	@FindBy(id="uk.nhs.covid19.internal:id/titleRiskLevel")
	WebElement RiskLevelMessage;
	
	@FindBy(xpath="//android.widget.ImageButton[@content-desc='Go back']")
	WebElement CloseRiskLevelMessage;
	
	public String getTextRiskLevelMessage ()
	{
		String riskmessage= RiskLevelMessage.getText();
		return riskmessage;
	}
	
	public void closeriskLevelMessage()
	{
		CloseRiskLevelMessage.click();
	}
 
}
