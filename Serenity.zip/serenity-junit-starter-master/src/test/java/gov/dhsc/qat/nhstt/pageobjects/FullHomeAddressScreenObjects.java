package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class FullHomeAddressScreenObjects extends MainScreenObjects
{
	
public FullHomeAddressScreenObjects(WebDriver driver) throws IOException
{
		super(driver);
	}

@FindBy(id="#submit-postcode-home")
WebElement findaddress;

public void clickOnFindAddress()
{
	findaddress.click();
}

}
