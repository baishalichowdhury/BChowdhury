package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASStayOverNightScreen extends HomeScreenObjects
{

	public CTASStayOverNightScreen(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(css="#backwards-tracing-state-stayed-overnight-true-field")
	WebElement yesStayed;
	
	@FindBy(css="#backwards-tracing-state-stayed-overnight-field")
	WebElement notStayed;
	
	public void didYouStayOverNight(String option) throws InterruptedException
	{
		Thread.sleep(2000);
		if(option.equalsIgnoreCase("Yes"))
		{
			yesStayed.click();
		}
		else if(option.equalsIgnoreCase("No"))
		{
			notStayed.click();
		}
	}

}
