package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class NInumberScreenObjects extends MainScreenObjects {
	
	
	
	
public NInumberScreenObjects(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}

@FindBy(id="x-yes-nino")
WebElement ninumberavailable;

@FindBy(css="#nino--4 > input")
WebElement ninumber;

public void niNumberAvailable()
{
	ninumberavailable.click();
}

@FindBy(xpath="//*[@id='2-next-details-top']")
WebElement ContinueNINumber;

public void enterNINumber()
{
	ninumber.sendKeys(prop.getProperty("NInumber"));
	ContinueNINumber.click();
	
}


}
