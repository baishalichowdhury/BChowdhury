package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class BookFreeTestScreenObjects extends MainScreenObjects
{
	WebDriverWait wait;
	
	@FindBy(id="uk.nhs.covid19.internal:id/orderTest")
	WebElement bookFreeTestNowbtn;
	
	@FindBy(id="postcode-number")
	WebElement POST_CODE_INPUT;
	
	@FindBy(xpath="//android.view.View[contains(@resource-id,'main-content')]")
	WebElement confirmDetails;
	
	@FindBy(xpath="(//div[@class='govuk-summary-list__row' and dt[contains(text(), 'Date and time')]])//dd")
	WebElement dateAndTimeSlot;
	
	@FindBy(xpath="(//android.widget.RadioButton[contains(@id,'test-centre')]")
	List<WebElement> siteAvailable;       
	
	@FindBy(xpath="//android.widget.Button[contains(@text ='Find a test site')]")
	WebElement Continuefromchoosesite;
	
	@FindBy(xpath="//android.widget.Button[contains(@text ='Continue')]")
	WebElement Continue;
	
	@FindBy(xpath="//android.widget.RadioButton[contains(@resource-id ,'time')]")
	List<WebElement> timeslot;
	
	@FindBy(xpath="//android.widget.Button[contains(@text= 'Save and continue')]")
	WebElement saveAndContiniueAppointmentDetails;
	
	@FindBy(xpath="//android.widget.TextView[contains(@text= 'View or print pass')]")
	WebElement ViewOrPrintPass;
	
	@FindBy(xpath="//android.view.View[contains(text(), 'Pass ID')]")
	WebElement PassId;
	
	public void clickOnBookFreeTestNow()
	{
	//	new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
		bookFreeTestNowbtn.click();
	}
	
	 public void enterPostcode(String postcode) 
	 {
		 POST_CODE_INPUT.clear();
		 POST_CODE_INPUT.sendKeys(postcode);
		 Continuefromchoosesite.click();
	    }
	 
	 
	 public void confirmAppointmentDetails() throws InterruptedException 
	 { 
		 String CONFIRM_APPOINTMENT = "Confirm your appointment";
		 wait.until(ExpectedConditions.visibilityOf(confirmDetails));  
		 String Message= confirmDetails.getText();
		Assert.assertTrue(Message.contains(CONFIRM_APPOINTMENT));
		MainScreenObjects.swipeToBottom();
		saveAndContiniueAppointmentDetails.click();
	    }
	 
	 public void chooseTestSite() 
	 { 
		 WebElement site= siteAvailable.get(0);
	     site.click();
	     Continue.click();
	     
     }
	 
	 public void chooseTimeSlot() throws InterruptedException 
	 { 
		 MainScreenObjects.swipeToBottom();
		 WebElement Timeslot= timeslot.get(0);
		 Timeslot.click();
		 MainScreenObjects.swipeToBottom(); 
      }
	 
	 public void confirmAppointmnet()
	 {
		 Continue.click(); 
	 }
	 
	 public void confirmAppointmnetBooked() throws InterruptedException
	 {
		 String APPOINTMENT_BOOKED = "Appointment booked";
		 wait.until(ExpectedConditions.visibilityOf(confirmDetails));  
		 String Message= confirmDetails.getText();
		Assert.assertTrue(Message.contains(APPOINTMENT_BOOKED));
		 MainScreenObjects.swipeToBottom();
		 ViewOrPrintPass.click();
		 MainScreenObjects.swipeToBottom();
		 String PassID= PassId.getText();
         System.out.println(PassID);
		
	 }
	 
	public BookFreeTestScreenObjects(AppiumDriver<MobileElement> driver) throws IOException 
	{
		super(driver);
	}
	
	
}
