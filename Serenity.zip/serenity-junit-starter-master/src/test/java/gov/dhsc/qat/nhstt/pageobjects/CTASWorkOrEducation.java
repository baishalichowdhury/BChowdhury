package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASWorkOrEducation extends HomeScreenObjects
{

	public CTASWorkOrEducation(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(css="#main-content > div > div > form > a")
	WebElement notInWorkAndnotEducated;
	
	public void clickNotInWorkAndnotEducated()
	{
		notInWorkAndnotEducated.click();
	}
}
