package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class EmployerDetailsScreenObjects extends MainScreenObjects{
	
	public EmployerDetailsScreenObjects(WebDriver driver) throws IOException 
	{
		super(driver);
	}

	
@FindBy(id="employer")
WebElement employer;

@FindBy(css="#main-content > div > div > form > button")
WebElement continueBtn;
public void employerDetails()
{
	employer.sendKeys(prop.getProperty("employer"));
	continueBtn.click();
}

}
