package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASWhereCaughtCovid extends HomeScreenObjects
{

	public CTASWhereCaughtCovid(WebDriver driver) throws IOException 
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
  @FindBy(xpath="//*[text()[contains(.,'Continue')]]")
  WebElement continueBtn;
  
  public void clickOnContinue()
  {
	  continueBtn.click();
  }
}
