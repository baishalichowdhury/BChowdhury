package gov.dhsc.qat.nhstt.pageobjects;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CTASLoginScreenObjects extends HomeScreenObjects
{

	public CTASLoginScreenObjects(WebDriver driver) throws IOException
	{
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(css="#individual-account-id-field")
	WebElement accountIdField;
	
	@FindBy(css="#individual-password-field")
	WebElement passowrdField;
	
	@FindBy(css="#new_individual > input.nhsuk-button.nhsuk-button--primary")
	WebElement logInBtn;
	
	@FindBy(css="#main-content > div > div > div > div > a")
	WebElement signInBtn;
	
	@FindBy(css="#header-navigation > div > ul > li > a")
	WebElement signOut;
	
	public void clickOnSignInBtn()
	{
		signInBtn.click();
	}
	
	public void signIn(String AccountId, String Password)
	{
		accountIdField.sendKeys(AccountId);
		passowrdField.sendKeys(Password);
		logInBtn.click();
	}
	
	public void signOut() throws InterruptedException
	{
		Thread.sleep(2000);
		signOut.click();
	}
}
