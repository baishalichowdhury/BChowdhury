package gov.dhsc.qat.nhstt.pageobjects;

import static io.appium.java_client.touch.offset.PointOption.point;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class MainScreenObjects_old extends HomeScreenObjects
{

	public MainScreenObjects_old(WebDriver driver) throws IOException {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy (xpath="//android.widget.LinearLayout[@content-desc=\"Book a free test, Button\"]")
	WebElement bookFreeTest;
	
	@FindBy (id="uk.nhs.covid19.internal:id/optionReportSymptoms")
	WebElement checkSymptomsbtn;
	
	
	@FindBy (id="uk.nhs.covid19.internal:id/riskyPostCode")
	WebElement riskyPostcodebtn;
	
	@FindBy (id="uk.nhs.covid19.internal:id/riskAreaView")
	WebElement riskLevelStatus;
	
	 @FindBy(id="uk.nhs.covid19.internal:id/subTitleIsolationCountdown")
	 WebElement selfisolatemessage;
	
	public void clickOncheckSymptomsbtn() 
	{	
		checkSymptomsbtn.click();
	}
	
	public void clickOnBookFreeTest()
	{
		bookFreeTest.click();
	}
	
	public void clickRiskyPostcodebtn() 
	{	
		 riskyPostcodebtn.click();
		 
	}
	
	public void clickOnriskLevelStatus() 
	{	
		riskLevelStatus.click();
	}
	
	 public String selfIsolateMessage()
	 {
		return selfisolatemessage.getText();
		
	 }
	
	public void scroll()
	{
		/*TouchAction ts = new TouchAction(driver);
		ts.press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();*/
		
	//	ts.press(point(540, 1038)).moveTo(point(540, 415)).release().perform();
	//	ts.press(point(540, 540)).moveTo(point(540, 50)).release().perform();
	//	ts.press(point(540, 1300)).moveTo(point(540, 50)).release().perform();

		
	}
	@SuppressWarnings("rawtypes")
	public static void swipeToBottom() throws InterruptedException
	{		 
		//  new TouchAction(driver).press(point(540,540)).waitAction().moveTo(point(540, 10)).release().perform();
		//  Thread.sleep(500);
		  
		 /* Thread.sleep(1000);
		  TouchAction ts = new TouchAction(driver);
		  ts.press(point(1078, 1640)).moveTo(point(1078, 340)).release().perform();
		  Thread.sleep(1000);*/
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,1000)");
	
		
	}
	public static void swipeToBottom2() throws InterruptedException
	{		 
		JavascriptExecutor js= (JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,3000)");
	
		}
	
	
}

