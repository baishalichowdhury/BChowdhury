package DempProject.base;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import testDataTypes.User;

public class JSONDataReader
{
	static String UserDir=System.getProperty("user.dir");
	static String FilePath;
	 private static List<User> TestDataList;
	 
	/* public JSONDataReader(){
	 customerList = getCustomerData();
	 }
	 */
		 
	/* public static List<Customer> getCustomerData() 
	 {
		 Gson gson = new Gson();
			BufferedReader bufferReader = null;
			try {
				bufferReader = new BufferedReader(new FileReader(customerFilePath));
				Customer[] customers = gson.fromJson(bufferReader, Customer[].class);
				System.out.println(customers);
				return Arrays.asList(customers);
				}
			
			catch(FileNotFoundException e) {
				throw new RuntimeException("Json file not found at path : " + customerFilePath);
			}finally {
				try { if(bufferReader != null) bufferReader.close();}
				catch (IOException ignore) {}
			}
		
	}*/

	public final static User getValueByUserId(String UserId,String filename) throws FileNotFoundException
	{
		TestDataList = readJSON(filename);
		 for(User data : TestDataList) 
		 { 
		 if(data.userid.equalsIgnoreCase(UserId))
			 System.out.println(data);
			 return data;
		 }
		 return null;
	}
	 
	public static List<User> readJSON(String filename) throws FileNotFoundException
	{ 
		FilePath=UserDir+"/src/test/resources/testDataResources/"+filename;
		Gson gson = new Gson();
		JsonParser parser= new JsonParser();
		FileReader reader= new FileReader(FilePath);
		User[] testData = gson.fromJson(reader,User[].class);
		return(Arrays.asList(testData));
	}
	
	
	public static JsonObject read(String filename) throws JsonIOException, JsonSyntaxException, FileNotFoundException
	{
		FilePath=UserDir+"/src/test/resources/testDataResources/"+filename;
		JsonParser parser = new JsonParser();
		Object obj = parser.parse(new FileReader(FilePath));
		JsonObject jsonObject = (JsonObject) obj;
		return (jsonObject);
	}
	
	public static void getDataByKey(String key, String filename) throws JsonIOException, JsonSyntaxException, FileNotFoundException
	{ 
		JsonObject testData=read(filename);
		if(testData.get(key) != null)
		{
			JsonElement el= (testData.get("firstname"));
			String firstname= el.getAsString();
			System.out.println(firstname);
		}
		
	}
	 public static void main(String ar[]) throws IOException, ParseException
	 {
		/* User cust= getValueByUserId("sc2014tc001","User.json");
		 System.out.println(cust.lastName);
		 System.out.println(cust.email);*/
		 
		// getDataByKey("firstname","User.json");
		 
		 
		 
	 }
}
