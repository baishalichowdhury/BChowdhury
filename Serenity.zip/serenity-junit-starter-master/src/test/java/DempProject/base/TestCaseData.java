package DempProject.base;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class TestCaseData {
	
	static HashMap<String , String> tcData =  new HashMap<String,String>();
	public TestCaseData() 
	{
		// TODO Auto-generated constructor stub
	}

	public void readTestCaseData(String fileName) throws IOException, ParseException
	{
		String FilePath1="C:\\Users\\BChowdhury_adm\\Desktop\\serenity-junit-starter-master/src/test/java/";
		String FilePath= FilePath1+fileName;  //"sc2011tc001.json";
		//read the json file
		JSONParser jsonparser= new JSONParser ();
		FileReader reader= new FileReader(FilePath);
		Object ob= jsonparser.parse(reader);	
		JSONArray tcDataList= (JSONArray)ob;      // entire json file
		//System.out.println(tcDataList);
		for(int i=0;i<tcDataList.size();i++)
		{
			JSONObject tcDatas= (JSONObject)tcDataList.get(i);
		//	System.out.println(tcDatas);// complete block
			Set keys =  tcDatas.keySet();
			System.out.println(keys);
			for (Iterator<String> it = keys.iterator(); it.hasNext();)
			{
				String key= it.next();
				String value =   tcDatas.getOrDefault(key, "valuenotfound").toString();              //(String) tcData.get("key");
				/*System.out.println(key);
				System.out.println(value);*/
				tcData.put(key, value);
			}
			
		}
	}
	
	public String getValueForKey(String key, String optionalValue)
	{
		String value = optionalValue;
		
		if(tcData.containsKey(key))
		{
			value = tcData.get(key);
		}	
		
		return value;
	}
	
	public void setValueForKey(String key, String value)
	{
		if(tcData.containsKey(key))
		{
			tcData.put(key, value);
		}	
		
	}
	
	public void writeJSON(String fileName)
	{
		//Save TestCaseData object to filename
	}
	
}
