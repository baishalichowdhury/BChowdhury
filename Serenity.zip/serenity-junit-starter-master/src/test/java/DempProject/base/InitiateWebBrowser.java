package DempProject.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.SortedSet;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import gov.dhsc.qat.nhstt.pageobjects.AppRegistrationObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASAboutHealthScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASAboutYouScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASActivitiesOutSideScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASAnyActivitiesYouDid;
import gov.dhsc.qat.nhstt.pageobjects.CTASContactFeedbackScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASDidYouLeaveHomeScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASDidYouStayOverNight;
import gov.dhsc.qat.nhstt.pageobjects.CTASIsolationInformationScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASLoginScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASMoreAboutWhereYouLiveObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASNewPersonDetailScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASStayOverNightScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASThankYouScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASVulnerableMarkersScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASWelcomeScreenObjets;
import gov.dhsc.qat.nhstt.pageobjects.CTASWhereCaughtCovid;
import gov.dhsc.qat.nhstt.pageobjects.CTASWhereYouLiveScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.CTASWhereYouMightCaugthCovid;
import gov.dhsc.qat.nhstt.pageobjects.CTASWhoYouLiveWithScreen;
import gov.dhsc.qat.nhstt.pageobjects.CTASWorkOrEducation;
import gov.dhsc.qat.nhstt.pageobjects.EssentialWorkerScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.HomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.MainScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.OutcomeScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.ReviewSymptomsScreenObjects;
import gov.dhsc.qat.nhstt.pageobjects.SymptomsCheckerScreenObjects;
import testDataTypes.User;


public class InitiateWebBrowser 
{
public static WebDriver driver = null;
static WebDriverWait wait;
static Set<String> contextNames;
public static Properties prop;
public static String UserDir;
public static Object obj; 


public InitiateWebBrowser() throws IOException
{
	prop = new Properties();
//	if(prop.containsKey(key))
	UserDir=System.getProperty("user.dir");
	System.out.println(UserDir);
	String FilePath= UserDir+"/src/test/resources/config.properties";
	FileInputStream fis= new FileInputStream(FilePath);
	prop.load(fis);
}

public static void initiateWebBrowser () throws IOException
{
	String browser = prop.getProperty("browsername");
	if(browser.equalsIgnoreCase("chrome"))
		{ChromeOptions option = new ChromeOptions(); 
		option.addArguments("--no-sandbox");
		String driverpath= UserDir+"/WebDriver/chromedriver.exe";
		System.out.println(UserDir);
		System.out.println(driverpath);
		System.setProperty("webdriver.chrome.driver", driverpath);
		driver = new ChromeDriver(option);
	}
	else if(browser.equalsIgnoreCase("firefox"))
	{
		String driverpath= UserDir+"/WebDriver/geckodriver.exe";
		System.setProperty("webdriver.gecko.driver", driverpath);
		driver = new FirefoxDriver();
	}
	else if(browser.equalsIgnoreCase("internetexplorer"))
	{
		InternetExplorerOptions caps = new InternetExplorerOptions();
		caps.disableNativeEvents();
		String driverpath= UserDir+"/WebDriver/IEDriverServer.exe";
		System.setProperty("webdriver.ie.driver", driverpath);
		driver = new InternetExplorerDriver(caps);
	}
	else
	{
		System.out.println("Enter chrome or firefox");
	}
		
	new HomeScreenObjects(driver);
	new MainScreenObjects(driver);
	new SymptomsCheckerScreenObjects(driver);
	new ReviewSymptomsScreenObjects(driver);
	new OutcomeScreenObjects(driver);
	new AppRegistrationObjects(driver);
	new EssentialWorkerScreenObjects(driver);
	new CTASAboutYouScreenObjects(driver);
	new CTASLoginScreenObjects(driver);
	new CTASWelcomeScreenObjets(driver);
	new CTASContactFeedbackScreenObjects(driver);
	new CTASAboutHealthScreenObjects(driver);
	new CTASDidYouStayOverNight(driver);
	new CTASIsolationInformationScreenObjects(driver);
	new CTASMoreAboutWhereYouLiveObjects(driver);
	new CTASNewPersonDetailScreen(driver);
	new CTASVulnerableMarkersScreenObjects(driver);
	new CTASWhereYouLiveScreenObjects(driver);
	new CTASMoreAboutWhereYouLiveObjects(driver);
	new CTASWhereYouMightCaugthCovid(driver);
	new CTASWhoYouLiveWithScreen(driver);
	new CTASWorkOrEducation(driver);
	new CTASActivitiesOutSideScreen(driver);
	new CTASWhereCaughtCovid(driver);
	new CTASStayOverNightScreen(driver);
	new CTASDidYouLeaveHomeScreen(driver);
	new CTASAnyActivitiesYouDid(driver);
	new CTASThankYouScreen(driver);
}

public String getValueForProperty(String propertyName, String defaultValue)
{
	String value = defaultValue;
	if(prop.containsKey(propertyName))
	{
		value = prop.getProperty(propertyName);
	}
	else
	{
		System.out.println("Property: " + propertyName + "not found.");
	}	
	return value; 
}


/*public TestCaseData getTestData() throws IOException, ParseException
{
	
	return tcData;
	
}
*/
}
