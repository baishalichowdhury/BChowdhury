package testDataTypes;


public class User {

public String userid;
public String havingcoronasymptom;
public String symptomstartdate;
public String symptomstartmonth;
public String symptomstartyear;
public String essentialworker;
public String firstName;
public String lastName;
public String havingmobileno;
public String mobileno;
public String haveemail;
public String email;
public String postcode;
public String vehicleaccess;
public String dayofbirth;
public String monthofbirth;
public String yearofbirth;
public String landlineAccess;
public String gender;
public String ethnicgroup;
public String ethnicbackground;
public String currentlyinwork;
public String country;
public String knowNHS;
public String nhsnumber;
public String vehicleregistrationno;
public String partofpilotproject;
public String testsite;
public String timeslot;

}